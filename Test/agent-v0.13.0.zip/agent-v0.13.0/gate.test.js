"use strict";

const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const {
  resolveInside, classifyCommand, ApprovalQueue, PolicyError,
  globToRegExp, sanitizeForTerminal, makeDiffPreview, previewContent,
  sessionCategoryFor, isPrivateAddress, htmlToText,
  parsePolicy, policyAllows,
} = require("./gate");

let passed = 0, failed = 0;
function t(name, fn) {
  try { fn(); passed++; console.log("PASS", name); }
  catch (e) { failed++; console.log("FAIL", name, "->", e.message); }
}
function code(fn) {
  try { fn(); return null; } catch (e) { return e instanceof PolicyError ? e.code : "NOT_POLICY:" + e.message; }
}

// Fixture: project root with a token file, a symlink escaping the root, and a file inside.
const base = fs.mkdtempSync(path.join(os.tmpdir(), "gate-"));
const root = path.join(base, "proj");
const outside = path.join(base, "outside");
fs.mkdirSync(root); fs.mkdirSync(outside);
fs.writeFileSync(path.join(outside, "secret.txt"), "x");
fs.writeFileSync(path.join(root, "app.py"), "print(1)\n");
fs.mkdirSync(path.join(root, "src"));
fs.writeFileSync(path.join(root, "src", "mod.py"), "");
fs.symlinkSync(outside, path.join(root, "escape_dir"));
fs.symlinkSync(path.join(outside, "secret.txt"), path.join(root, "escape_file"));
fs.writeFileSync(path.join(root, "bridge.token"), "tok");
fs.mkdirSync(path.join(root, ".ssh"));
fs.writeFileSync(path.join(root, ".env"), "A=1");

// ---- path confinement: allowed ----
t("relative file inside root", () => {
  assert.strictEqual(resolveInside(root, "app.py"), path.join(fs.realpathSync(root), "app.py"));
});
t("nested file inside root", () => {
  resolveInside(root, "src/mod.py");
});
t("new file that does not exist yet, inside root", () => {
  resolveInside(root, "src/new_file.py");
});
t("new nested dir path inside root", () => {
  resolveInside(root, "build/out/x.txt");
});

// ---- path confinement: refused ----
t("dotdot escape refused", () => assert.strictEqual(code(() => resolveInside(root, "../outside/secret.txt")), "outside_project"));
t("deep dotdot escape refused", () => assert.strictEqual(code(() => resolveInside(root, "src/../../outside/secret.txt")), "outside_project"));
t("absolute path refused", () => assert.strictEqual(code(() => resolveInside(root, "/etc/passwd")), "absolute_path_refused"));
t("symlink dir pointing outside refused", () => assert.strictEqual(code(() => resolveInside(root, "escape_dir/secret.txt")), "outside_project"));
t("symlink file pointing outside refused", () => assert.strictEqual(code(() => resolveInside(root, "escape_file")), "outside_project"));
t("new file under escaping symlink refused", () => assert.strictEqual(code(() => resolveInside(root, "escape_dir/new.txt")), "outside_project"));
t("null byte refused", () => assert.strictEqual(code(() => resolveInside(root, "a\0b")), "invalid_path"));
t("empty path refused", () => assert.strictEqual(code(() => resolveInside(root, "")), "path_required"));
t("non-string path refused", () => assert.strictEqual(code(() => resolveInside(root, 42)), "path_required"));

// ---- protected names ----
t("bridge.token refused", () => assert.strictEqual(code(() => resolveInside(root, "bridge.token")), "protected_path"));
t(".env refused", () => assert.strictEqual(code(() => resolveInside(root, ".env")), "protected_path"));
t(".ssh dir refused", () => assert.strictEqual(code(() => resolveInside(root, ".ssh/id_rsa")), "protected_path"));
t("nested .env refused", () => assert.strictEqual(code(() => resolveInside(root, "src/.env")), "protected_path"));
t(".cfb path refused", () => assert.strictEqual(code(() => resolveInside(root, ".cfb/bridge.token")), "protected_path"));

// ---- classification: allowed read-only ----
t("ls allowed", () => assert.strictEqual(classifyCommand("ls -la").level, "allow"));
t("git status allowed", () => assert.strictEqual(classifyCommand("git status").level, "allow"));
t("git diff now asks (it can write files with --output)", () => assert.strictEqual(classifyCommand("git diff --stat").level, "ask"));
t("cat allowed", () => assert.strictEqual(classifyCommand("cat app.py").level, "allow"));

// ---- classification: must ask ----
t("npm test asks (not allowlisted)", () => assert.strictEqual(classifyCommand("npm test").level, "ask"));
t("rm -rf asks", () => assert.strictEqual(classifyCommand("rm -rf build").level, "ask"));
t("rm -r asks", () => assert.strictEqual(classifyCommand("rm -r build").level, "ask"));
t("rm -f asks", () => assert.strictEqual(classifyCommand("rm -f x").level, "ask"));
t("git push asks", () => assert.strictEqual(classifyCommand("git push origin main").level, "ask"));
t("git reset --hard asks", () => assert.strictEqual(classifyCommand("git reset --hard HEAD").level, "ask"));
t("git clean asks", () => assert.strictEqual(classifyCommand("git clean -fd").level, "ask"));
t("sudo asks", () => assert.strictEqual(classifyCommand("sudo ls").level, "ask"));
t("curl asks", () => assert.strictEqual(classifyCommand("curl https://x.example").level, "ask"));
t("chmod asks", () => assert.strictEqual(classifyCommand("chmod 777 app.py").level, "ask"));
t("pipe to allowlisted ls still asks", () => assert.strictEqual(classifyCommand("ls | sh").level, "ask"));
t("semicolon chain asks", () => assert.strictEqual(classifyCommand("ls; rm -rf x").level, "ask"));
t("command substitution asks", () => assert.strictEqual(classifyCommand("ls $(rm -rf x)").level, "ask"));
t("backticks ask", () => assert.strictEqual(classifyCommand("ls `id`").level, "ask"));
t("redirect asks", () => assert.strictEqual(classifyCommand("cat app.py > out").level, "ask"));
t("reference to .cfb asks", () => assert.strictEqual(classifyCommand("cat ~/.cfb/bridge.token").level, "ask"));
t("empty command refused", () => assert.strictEqual(code(() => classifyCommand("   ")), "command_required"));
t("oversized command refused", () => assert.strictEqual(code(() => classifyCommand("a".repeat(2001))), "command_too_long"));

// ---- approval state machine ----
let clock = 0;
const now = () => clock;

t("approve pending -> approved", () => {
  const q = new ApprovalQueue({ timeoutMs: 1000, now });
  q.create("r1", "write app.py");
  assert.deepStrictEqual(q.decide("r1", "approve"), { ok: true, state: "approved" });
});
t("deny pending -> denied", () => {
  const q = new ApprovalQueue({ timeoutMs: 1000, now });
  q.create("r2", "rm x");
  assert.deepStrictEqual(q.decide("r2", "deny"), { ok: true, state: "denied" });
});
t("cannot decide twice (replay)", () => {
  const q = new ApprovalQueue({ timeoutMs: 1000, now });
  q.create("r3", "x");
  q.decide("r3", "approve");
  assert.deepStrictEqual(q.decide("r3", "approve"), { ok: false, error: "already_approved" });
  assert.deepStrictEqual(q.decide("r3", "deny"), { ok: false, error: "already_approved" });
});
t("unknown request id rejected", () => {
  const q = new ApprovalQueue({ timeoutMs: 1000, now });
  assert.deepStrictEqual(q.decide("nope", "approve"), { ok: false, error: "unknown_approval" });
});
t("expired request cannot be approved (fails closed)", () => {
  clock = 0;
  const q = new ApprovalQueue({ timeoutMs: 1000, now });
  q.create("r4", "x");
  clock = 1000;
  assert.deepStrictEqual(q.decide("r4", "approve"), { ok: false, error: "already_expired" });
  assert.strictEqual(q.get("r4").state, "expired");
});
t("invalid decision value rejected, request stays pending", () => {
  clock = 0;
  const q = new ApprovalQueue({ timeoutMs: 1000, now });
  q.create("r5", "x");
  assert.deepStrictEqual(q.decide("r5", "yes"), { ok: false, error: "invalid_decision" });
  assert.strictEqual(q.get("r5").state, "pending");
});
t("duplicate id at creation refused", () => {
  const q = new ApprovalQueue({ timeoutMs: 1000, now });
  q.create("r6", "x");
  assert.strictEqual(code(() => q.create("r6", "y")), "duplicate_approval_id");
});

// ---- glob ----
t("glob *.py matches top-level only", () => {
  const re = globToRegExp("*.py");
  assert.ok(re.test("a.py")); assert.ok(!re.test("src/a.py"));
});
t("glob **/*.py matches any depth including top", () => {
  const re = globToRegExp("**/*.py");
  assert.ok(re.test("a.py")); assert.ok(re.test("src/x/a.py")); assert.ok(!re.test("a.pyc"));
});
t("glob src/** matches below src", () => {
  const re = globToRegExp("src/**");
  assert.ok(re.test("src/a/b.js")); assert.ok(!re.test("lib/a.js"));
});
t("glob ? matches one char, dot is literal", () => {
  const re = globToRegExp("a?.js");
  assert.ok(re.test("ab.js")); assert.ok(!re.test("a.js")); assert.ok(!re.test("abXjs"));
});
t("glob regex metacharacters are literal", () => {
  const re = globToRegExp("a+(b).txt");
  assert.ok(re.test("a+(b).txt")); assert.ok(!re.test("aab.txt"));
});
t("glob too many wildcards refused", () => assert.strictEqual(code(() => globToRegExp("*".repeat(9))), "invalid_glob"));
t("glob empty / too long refused", () => {
  assert.strictEqual(code(() => globToRegExp("")), "invalid_glob");
  assert.strictEqual(code(() => globToRegExp("a".repeat(201))), "invalid_glob");
});
t("repeated **/ is collapsed and stays fast on a long path", () => {
  const re = globToRegExp("**/**/**/**/**/**/**/**/x");
  const t0 = Date.now(); re.test("a/".repeat(2000) + "y");
  assert.ok(Date.now() - t0 < 500, "slow: " + (Date.now() - t0));
  assert.ok(re.test("a/b/c/x"));
});
t("separated ** groups stay fast on realistic depth (20 segments)", () => {
  const re = globToRegExp("**/a/**/b/**/c/**/d");
  const t0 = Date.now(); re.test("a/".repeat(20) + "z");
  assert.ok(Date.now() - t0 < 500, "slow: " + (Date.now() - t0));
});
t("more than four ** groups refused", () => assert.strictEqual(code(() => globToRegExp("**/a/**/b/**/c/**/d/**/e/**")), "invalid_glob"));

// ---- terminal sanitizing ----
t("escape sequences are shown, not executed", () => {
  const out = sanitizeForTerminal("ls\x1b[2J\x1b[Hsafe");
  assert.ok(!out.includes("\x1b")); assert.ok(out.includes("\\u{1b}"));
});
t("carriage return cannot overwrite the prompt line", () => {
  const out = sanitizeForTerminal("rm -rf x\rls");
  assert.ok(!out.includes("\r")); assert.ok(out.includes("\\u{d}"));
});
t("bidi override is made visible", () => {
  const out = sanitizeForTerminal("a\u202Eb");
  assert.ok(!out.includes("\u202e")); assert.ok(out.includes("\\u{202e}"));
});
t("newline and tab are preserved", () => assert.strictEqual(sanitizeForTerminal("a\n\tb"), "a\n\tb"));

// ---- previews ----
t("diff preview shows both sides and truncates", () => {
  const out = makeDiffPreview("a\nb\nc\nd\ne\nf\ng\nh", "x", 3);
  assert.ok(out.startsWith("- a")); assert.ok(out.includes("+ x")); assert.ok(out.includes("more lines"));
  const full = makeDiffPreview("a\nb\nc\nd\ne\nf\ng\nh", "x");
  assert.ok(full.includes("- h") && !full.includes("more lines"));
});
t("content preview truncates long files", () => {
  const out = previewContent(Array.from({ length: 300 }, (_, i) => "line" + i).join("\n"));
  assert.ok(out.includes("line0")); assert.ok(!out.includes("line299")); assert.ok(out.includes("more lines"));
});

// ---- session categories ----
t("plain command gets a per-program category", () => {
  const c = sessionCategoryFor("npm test"); assert.strictEqual(c.category, "exec:termux:npm");
});
t("category is per program: npm can be granted, git never is", () => {
  assert.ok(sessionCategoryFor("npm test"));
  assert.strictEqual(sessionCategoryFor("git status"), null);
});
t("category includes the environment", () => assert.strictEqual(sessionCategoryFor("npm test", "ubuntu").category, "exec:ubuntu:npm"));
t("rm never offers always", () => assert.strictEqual(sessionCategoryFor("rm file.txt"), null));
t("shells and eval never offer always", () => {
  for (const c of ["bash x.sh", "sh -c ls", "eval x", "env FOO=1 ls", "xargs ls", "nohup x"]) {
    assert.strictEqual(sessionCategoryFor(c), null, c);
  }
});
t("risky pattern never offers always", () => {
  assert.strictEqual(sessionCategoryFor("npm test && rm x"), null);
  assert.strictEqual(sessionCategoryFor("npm test | tee out"), null);
  assert.strictEqual(sessionCategoryFor("git push origin main"), null);
});

// ---- private address blocking ----
for (const ip of ["127.0.0.1", "10.0.0.5", "172.16.0.1", "172.31.255.255", "192.168.1.1", "169.254.169.254", "0.0.0.0",
                  "100.64.0.1", "224.0.0.1", "::1", "::", "fe80::1", "fc00::1", "fd12::1", "ff02::1",
                  "::ffff:127.0.0.1", "::ffff:7f00:1", "::ffff:10.1.2.3", "64:ff9b::7f00:1", "not-an-ip"]) {
  t("blocked address " + ip, () => assert.strictEqual(isPrivateAddress(ip), true));
}
for (const ip of ["8.8.8.8", "1.1.1.1", "172.32.0.1", "172.15.255.255", "2606:4700:4700::1111", "::ffff:8.8.8.8"]) {
  t("public address allowed " + ip, () => assert.strictEqual(isPrivateAddress(ip), false));
}

// ---- html to text ----
t("html: scripts, styles, comments and tags removed", () => {
  const out = htmlToText("<html><style>p{}</style><script>alert(1)</script><!-- c --><h1>Title</h1><p>Hello &amp; bye</p></html>");
  assert.ok(out.includes("Title")); assert.ok(out.includes("Hello & bye"));
  assert.ok(!out.includes("alert")); assert.ok(!out.includes("p{}")); assert.ok(!out.includes("<"));
});
t("html: unclosed script drops the rest, does not hang", () => {
  const out = htmlToText("before<script>alert(1) after");
  assert.ok(out.includes("before")); assert.ok(!out.includes("after"));
});
t("html: pathological input is linear time", () => {
  const t0 = Date.now();
  htmlToText("<script".repeat(30000)); htmlToText("<".repeat(200000)); htmlToText("<!--".repeat(50000));
  assert.ok(Date.now() - t0 < 1500, "slow: " + (Date.now() - t0));
});

// ---- trusted-workspace policy ----
const P2 = parsePolicy({ auto_edit: true, auto_exec_prefixes: ["npm test", "node ", "git status", "git commit"], auto_fetch_hosts: ["docs.example.com"] });
t("policy: default parses to no auto commands", () => {
  const d = parsePolicy(undefined);
  assert.deepStrictEqual(d.auto_exec_prefixes, []); assert.strictEqual(d.auto_edit, false);
  assert.strictEqual(policyAllows(d, { kind: "edit" }).auto, false);
});
t("policy: unknown key refused (typo cannot widen access)", () => {
  assert.strictEqual(code(() => parsePolicy({ auto_exec_prefix: ["npm"] })), "policy_unknown_key:auto_exec_prefix");
});
t("policy: wrong types refused", () => {
  assert.strictEqual(code(() => parsePolicy({ auto_edit: "yes" })), "policy_invalid");
  assert.strictEqual(code(() => parsePolicy({ auto_exec_prefixes: "npm" })), "policy_invalid");
  assert.strictEqual(code(() => parsePolicy({ auto_exec_prefixes: [""] })), "policy_invalid");
  assert.strictEqual(code(() => parsePolicy("[1,2]")), "policy_invalid");
  assert.strictEqual(code(() => parsePolicy("{bad json")), "policy_invalid_json");
});
t("policy: edits auto when enabled, ask when disabled", () => {
  assert.strictEqual(policyAllows(P2, { kind: "edit" }).auto, true);
  assert.strictEqual(policyAllows(parsePolicy({ auto_edit: false }), { kind: "edit" }).auto, false);
});
t("policy: allowlisted command runs without asking", () => {
  assert.strictEqual(policyAllows(P2, { kind: "exec", command: "npm test" }).auto, true);
  assert.strictEqual(policyAllows(P2, { kind: "exec", command: "node app.js --x" }).auto, true);
});
t("policy: prefix must match a whole word (node does not cover nodemon-style names)", () => {
  assert.strictEqual(policyAllows(P2, { kind: "exec", command: "nodejs-evil" }).auto, false);
});
t("policy: npm prefix does not cover npm test-like injections", () => {
  assert.strictEqual(policyAllows(P2, { kind: "exec", command: "npm test; rm -rf x" }).auto, false);
  assert.strictEqual(policyAllows(P2, { kind: "exec", command: "npm test && curl x" }).auto, false);
  assert.strictEqual(policyAllows(P2, { kind: "exec", command: "npm test | sh" }).auto, false);
  assert.strictEqual(policyAllows(P2, { kind: "exec", command: "npm test $(id)" }).auto, false);
});
t("policy: hard blocks cannot be allowlisted", () => {
  const evil = parsePolicy({ auto_exec_prefixes: ["rm", "sudo", "git push", "curl", "bash", "sh -c"] });
  for (const c of ["rm -rf x", "rm file", "sudo ls", "git push origin main", "curl https://x", "bash x.sh", "sh -c ls"]) {
    assert.strictEqual(policyAllows(evil, { kind: "exec", command: c }).auto, false, c);
  }
});
t("policy: installs, publish and deploy always ask even if allowlisted", () => {
  const p = parsePolicy({ auto_exec_prefixes: ["npm", "pip"] });
  assert.strictEqual(policyAllows(p, { kind: "exec", command: "npm install express" }).auto, false);
  assert.strictEqual(policyAllows(p, { kind: "exec", command: "pip install requests" }).auto, false);
  assert.strictEqual(policyAllows(p, { kind: "exec", command: "npm publish" }).auto, false);
});
t("policy: non-listed command asks", () => {
  assert.strictEqual(policyAllows(P2, { kind: "exec", command: "make build" }).auto, false);
});
t("policy: fetch only for listed hosts, case-insensitive", () => {
  assert.strictEqual(policyAllows(P2, { kind: "fetch", host: "docs.example.com" }).auto, true);
  assert.strictEqual(policyAllows(P2, { kind: "fetch", host: "DOCS.example.com" }).auto, true);
  assert.strictEqual(policyAllows(P2, { kind: "fetch", host: "evil.example.com" }).auto, false);
  assert.strictEqual(policyAllows(P2, { kind: "fetch", host: "" }).auto, false);
});
t("policy: unknown request kind asks", () => assert.strictEqual(policyAllows(P2, { kind: "delete" }).auto, false));

// ---- audit findings: shell classifier, session grants, aliases, IPv6 ----
t("newline cannot smuggle a second command past the classifier", () => {
  assert.strictEqual(classifyCommand("pwd\npython3 -c \"print(1)\"").level, "ask");
  assert.strictEqual(classifyCommand("ls\r\nrm x").level, "ask");
  assert.strictEqual(classifyCommand("ls\0rm").level, "ask");
});
t("policy cannot auto-approve a multi-line command", () => {
  const p = parsePolicy({ auto_exec_prefixes: ["npm test"] });
  assert.strictEqual(policyAllows(p, { kind: "exec", command: "npm test\nprint(1)" }).auto, false);
  assert.strictEqual(policyAllows(p, { kind: "exec", command: "npm test\ncat .env" }).auto, false);
});
t("reads of protected names are not allowlisted", () => {
  for (const c of ["cat .env", "cat .netrc", "cat .git-credentials", "cat bridge.token", "head ~/.ssh/config", "cat src/.env"]) {
    assert.strictEqual(classifyCommand(c).level, "ask", c);
  }
});
t("absolute, home and parent paths in commands ask", () => {
  for (const c of ["cat /etc/passwd", "ls /", "cat ~/notes.txt", "cat ../../x", "wc ../secret"]) {
    assert.strictEqual(classifyCommand(c).level, "ask", c);
  }
});
t("ordinary relative reads still allowed", () => {
  assert.strictEqual(classifyCommand("cat src/app.py").level, "allow");
  assert.strictEqual(classifyCommand("ls -la src").level, "allow");
});
t("npm install never gets a session grant, npm test does", () => {
  assert.strictEqual(sessionCategoryFor("npm install express"), null);
  assert.strictEqual(sessionCategoryFor("npm i left-pad"), null);
  assert.strictEqual(sessionCategoryFor("npm add x"), null);
  assert.strictEqual(sessionCategoryFor("npm publish"), null);
  assert.ok(sessionCategoryFor("npm test"));
});
t("git push, pull, fetch, clone, remote never get a session grant", () => {
  for (const c of ["git push origin main", "git pull", "git fetch", "git clone x", "git remote add o x"]) {
    assert.strictEqual(sessionCategoryFor(c), null, c);
  }
});
t("policy cannot allowlist install/remote git operations", () => {
  const p = parsePolicy({ auto_exec_prefixes: ["git", "npm"] });
  for (const c of ["git pull", "git fetch origin", "git clone x", "npm install x", "npm config set x"]) {
    assert.strictEqual(policyAllows(p, { kind: "exec", command: c }).auto, false, c);
  }
});
t("symlink alias to a protected file is refused", () => {
  const base3 = fs.mkdtempSync(path.join(os.tmpdir(), "alias-"));
  const r3 = path.join(base3, "proj"); fs.mkdirSync(r3);
  fs.writeFileSync(path.join(r3, ".env"), "SECRET=1");
  fs.symlinkSync(path.join(r3, ".env"), path.join(r3, "innocent.txt"));
  assert.strictEqual(code(() => resolveInside(r3, "innocent.txt")), "protected_path");
  fs.rmSync(base3, { recursive: true, force: true });
});
t("IPv4-compatible and 6to4 addresses with private IPv4 are blocked", () => {
  assert.strictEqual(isPrivateAddress("::c0a8:101"), true);
  assert.strictEqual(isPrivateAddress("::a00:1"), true);
  assert.strictEqual(isPrivateAddress("2002:c0a8:101::1"), true);
  assert.strictEqual(isPrivateAddress("2002:0808:0808::1"), false);
});

// ---- second audit ----
t("git branch deletion/rename/force-move always asks", () => {
  for (const c of ["git branch -D main", "git branch --delete x", "git branch -m a b", "git branch -f main HEAD~1", "git branch"]) {
    assert.strictEqual(classifyCommand(c).level, "ask", c);
  }
});
t("git diff/show with output options always ask", () => {
  assert.strictEqual(classifyCommand("git diff --output=../o.txt").level, "ask");
  assert.strictEqual(classifyCommand("git show HEAD").level, "ask");
});
t("git status and git log stay allowed", () => {
  assert.strictEqual(classifyCommand("git status").level, "allow");
  assert.strictEqual(classifyCommand("git log -3").level, "allow");
});
t("shell variables that could build a path always ask", () => {
  assert.strictEqual(classifyCommand("cat $PREFIX/../home/.bashrc").level, "ask");
  assert.strictEqual(classifyCommand("cat $HOME/notes").level, "ask");
});
t("environment-file variants are protected", () => {
  for (const n of [".env", ".env.local", ".env.production", ".env.development.local"]) {
    assert.strictEqual(code(() => resolveInside(root, n)), "protected_path", n);
  }
  // .env.example is blocked too: copies of it often end up holding real values.
  assert.strictEqual(code(() => resolveInside(root, "config/.env.example")), "protected_path");
});
t("package credential files are protected", () => {
  assert.strictEqual(code(() => resolveInside(root, ".npmrc")), "protected_path");
  assert.strictEqual(code(() => resolveInside(root, ".pypirc")), "protected_path");
});
t("hard-linked file is refused (cannot be checked by name)", () => {
  const h = path.join(root, "linked.txt");
  try { fs.linkSync(path.join(root, "app.py"), h); } catch (e) { return; }
  try { assert.strictEqual(code(() => resolveInside(root, "linked.txt")), "hard_linked_file"); }
  finally { fs.unlinkSync(h); }
});
t("interpreters cannot get a session Always grant", () => {
  for (const c of ["node -e 1", "python3 x.py", "make build", "npx tool", "go test", "ruby x"]) {
    assert.strictEqual(sessionCategoryFor(c), null, c);
  }
});
t("npm run and friends cannot get a session Always grant", () => {
  for (const c of ["npm run deploy", "yarn run x", "pnpm exec x", "npx x", "npm x"]) {
    assert.strictEqual(sessionCategoryFor(c), null, c);
  }
});
t("policy can still allow an interpreter the user chose explicitly", () => {
  const p = parsePolicy({ auto_exec_prefixes: ["node "] });
  assert.strictEqual(policyAllows(p, { kind: "exec", command: "node tests/run.js" }).auto, true);
  assert.strictEqual(policyAllows(p, { kind: "exec", command: "node tests/run.js; rm x" }).auto, false);
});
t("policy still never auto-allows hard-blocked programs", () => {
  const p = parsePolicy({ auto_exec_prefixes: ["sh ", "bash ", "rm "] });
  assert.strictEqual(policyAllows(p, { kind: "exec", command: "sh x.sh" }).auto, false);
  assert.strictEqual(policyAllows(p, { kind: "exec", command: "rm x" }).auto, false);
});
t("IPv4-translated address ::ffff:0:a.b.c.d is classified", () => {
  assert.strictEqual(isPrivateAddress("::ffff:0:c0a8:101"), true);
  assert.strictEqual(isPrivateAddress("::ffff:0:0808:0808"), false);
});

console.log(`\n${passed} passed, ${failed} failed`);
fs.rmSync(base, { recursive: true, force: true });
process.exit(failed ? 1 : 0);
