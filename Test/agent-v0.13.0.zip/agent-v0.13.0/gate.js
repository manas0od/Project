"use strict";

const path = require("path");
const fs = require("fs");
const net = require("net");

// ---------- Project confinement ----------

// Resolve a user-supplied path against the project root. Refuses anything
// that escapes the root lexically, or through a symlink that points outside.
function resolveInside(root, requested) {
  if (typeof requested !== "string" || requested.length === 0) {
    throw new PolicyError("path_required");
  }
  if (requested.includes("\0")) {
    throw new PolicyError("invalid_path");
  }
  if (path.isAbsolute(requested)) {
    throw new PolicyError("absolute_path_refused");
  }

  const rootReal = fs.realpathSync(root);
  const candidate = path.resolve(rootReal, requested);
  const rel = path.relative(rootReal, candidate);

  if (rel.startsWith("..") || path.isAbsolute(rel)) {
    throw new PolicyError("outside_project");
  }

  // If the target (or its nearest existing parent) is a symlink that resolves
  // outside the root, refuse it.
  let probe = candidate;
  while (!fs.existsSync(probe)) {
    const parent = path.dirname(probe);
    if (parent === probe) break;
    probe = parent;
  }
  const probeReal = fs.realpathSync(probe);
  const probeRel = path.relative(rootReal, probeReal);
  if (probeRel.startsWith("..") || path.isAbsolute(probeRel)) {
    throw new PolicyError("outside_project");
  }

  if (isProtected(rootReal, candidate)) {
    throw new PolicyError("protected_path");
  }
  // A hard link is a second name for the same data, so it cannot be checked by name.
  // Refuse files with more than one name rather than guess which one is protected.
  if (fs.existsSync(candidate)) {
    const st = fs.lstatSync(candidate);
    if (st.isFile() && st.nlink > 1) throw new PolicyError("hard_linked_file");
  }
  // A symlink inside the project can alias a protected file under another name.
  if (fs.existsSync(candidate)) {
    const target = fs.realpathSync(candidate);
    const targetRel = path.relative(rootReal, target);
    if (targetRel.startsWith("..") || path.isAbsolute(targetRel)) {
      throw new PolicyError("outside_project");
    }
    if (isProtected(rootReal, target)) {
      throw new PolicyError("protected_path");
    }
  }

  return candidate;
}

// Files that must never be read or written through the bridge, even inside
// the project. Matched on the final path segment.
const PROTECTED_NAMES = new Set([
  "bridge.token",
  ".netrc",
  ".npmrc",
  ".pypirc",
  ".git-credentials",
  "id_rsa",
  "id_ed25519",
]);
// Environment files and their variants: .env, .env.local, .env.production, ...
const PROTECTED_PATTERNS = [/^\.env(\..+)?$/];

function isProtected(root, candidate) {
  const parts = path.relative(root, candidate).split(path.sep);
  if (parts.some(p => p === ".ssh" || p === ".gnupg" || p === ".cfb")) {
    return true;
  }
  const base = path.basename(candidate);
  return PROTECTED_NAMES.has(base) || PROTECTED_PATTERNS.some(re => re.test(base));
}

// ---------- Command classification ----------

// Commands that run without asking. Each entry is an exact argv prefix match
// on the first tokens; arguments after the prefix are checked separately.
const SAFE_COMMANDS = [
  ["ls"], ["pwd"], ["cat"], ["head"], ["tail"], ["wc"], ["file"], ["stat"],
  // Only forms that cannot write or change state. diff/show/branch are removed:
  // `git diff --output=...` writes files and `git branch -D` deletes branches.
  ["git", "status"], ["git", "log"], ["git", "rev-parse"],
];

// Always ask, with a warning. Checked before SAFE_COMMANDS.
const DANGEROUS_PATTERNS = [
  /\brm\s+(-[a-zA-Z]*[rRf][a-zA-Z]*\s|--recursive|--force)/,
  /\bgit\s+push\b/,
  /\bgit\s+reset\s+--hard\b/,
  /\bgit\s+clean\b/,
  /\bgit\s+checkout\s+--\s/,
  /\bsudo\b/,
  /\bsu\b\s/,
  /\bchmod\b/,
  /\bchown\b/,
  /\bcurl\b|\bwget\b|\bnc\b|\bssh\b|\bscp\b/,
  /\bdd\b\s/,
  /\bmkfs\b/,
  /\beval\b|\bexec\b/,
  /`|\$\(|\$\{/,      // command substitution can hide actions
  /[;&|<>]/,             // chaining, pipes, redirects always ask
  /\.cfb/,
  /[\r\n\0\x01-\x08\x0b\x0c\x0e-\x1f\x7f]/,   // newline starts a second command; control chars hide text
  /(^|\s)(\/|~|\.\.)/,                          // absolute, home or parent-directory paths reach outside the project
  /\.env[\w.-]*|\.netrc|\.npmrc|\.pypirc|\.git-credentials|\bbridge\.token|\.ssh|\.gnupg|id_rsa|id_ed25519/, // protected names
  /\$[A-Za-z_{]/,                                  // variables can build any path, so they always ask
];

function classifyCommand(command) {
  if (typeof command !== "string" || command.trim().length === 0) {
    throw new PolicyError("command_required");
  }
  if (command.length > 2000) {
    throw new PolicyError("command_too_long");
  }

  const dangerous = DANGEROUS_PATTERNS.find(re => re.test(command));
  if (dangerous) {
    return { level: "ask", reason: "matches a risky pattern: " + dangerous.source };
  }

  const tokens = command.trim().split(/\s+/);
  const safe = SAFE_COMMANDS.some(prefix =>
    prefix.every((tok, i) => tokens[i] === tok)
  );

  if (safe) {
    return { level: "allow", reason: "read-only command on allowlist" };
  }

  return { level: "ask", reason: "not on the allowlist" };
}

// ---------- Approval state machine ----------

// States: pending -> approved | denied | expired.
// A request can only be decided once. Unknown or already-decided IDs are
// rejected, so a replayed approval does nothing.
class ApprovalQueue {
  constructor({ timeoutMs = 120000, now = () => Date.now() } = {}) {
    this.timeoutMs = timeoutMs;
    this.now = now;
    this.requests = new Map();
  }

  create(id, description) {
    if (this.requests.has(id)) {
      throw new PolicyError("duplicate_approval_id");
    }
    // Finished records are kept briefly for audit, then dropped.
    const cutoff = this.now() - 10 * 60 * 1000;
    for (const [key, old] of this.requests) {
      if (old.state !== "pending" && old.expiresAt < cutoff) this.requests.delete(key);
    }
    const entry = {
      id,
      description,
      state: "pending",
      expiresAt: this.now() + this.timeoutMs,
    };
    this.requests.set(id, entry);
    return entry;
  }

  // Lazily expire, so a request can't be approved after its window closed.
  _sweep(entry) {
    if (entry.state === "pending" && this.now() >= entry.expiresAt) {
      entry.state = "expired";
    }
    return entry;
  }

  get(id) {
    const entry = this.requests.get(id);
    return entry ? this._sweep(entry) : null;
  }

  decide(id, decision) {
    const entry = this.get(id);
    if (!entry) return { ok: false, error: "unknown_approval" };
    if (entry.state !== "pending") {
      return { ok: false, error: "already_" + entry.state };
    }
    if (decision !== "approve" && decision !== "deny") {
      return { ok: false, error: "invalid_decision" };
    }
    entry.state = decision === "approve" ? "approved" : "denied";
    return { ok: true, state: entry.state };
  }
}

// ---------- Search, preview and fetch helpers (pure, no I/O) ----------

const SKIP_DIRS = new Set([".git", "node_modules", ".ssh", ".gnupg", ".cfb"]);

// Glob subset: **, *, ?. Everything else is literal. Bounded so a hostile
// pattern cannot cause catastrophic backtracking.
function globToRegExp(glob) {
  if (typeof glob !== "string" || glob.length === 0 || glob.length > 200) {
    throw new PolicyError("invalid_glob");
  }
  // "**/**/" means the same as "**/"; collapsing avoids polynomial backtracking.
  glob = glob.replace(/(\*\*\/)+/g, "**/");
  if ((glob.match(/\*\*/g) || []).length > 4 || (glob.match(/\*/g) || []).length > 8) {
    throw new PolicyError("invalid_glob");
  }

  let re = "";
  for (let i = 0; i < glob.length; i++) {
    const c = glob[i];
    if (c === "*") {
      if (glob[i + 1] === "*") {
        i++;
        if (glob[i + 1] === "/") { i++; re += "(?:[^/]+/)*"; }
        else re += ".*";
      } else {
        re += "[^/]*";
      }
    } else if (c === "?") {
      re += "[^/]";
    } else {
      re += c.replace(/[.+^${}()|[\]\\]/g, "\\$&");
    }
  }
  return new RegExp("^" + re + "$");
}

// Terminal control characters in a prompt could clear the screen, overwrite
// the line with \r, or reorder text (bidi) to disguise what is being approved.
// Everything except newline and tab is shown as a visible escape instead.
function sanitizeForTerminal(text) {
  return String(text).replace(
    /[\u0000-\u0008\u000b-\u001f\u007f-\u009f\u200b-\u200f\u2028\u2029\u202a-\u202e\u2066-\u2069\ufeff]/g,
    ch => "\\u{" + ch.codePointAt(0).toString(16) + "}"
  );
}

function clip(str, max = 500) {
  return str.length > max ? str.slice(0, max) + "…" : str;
}

function sideOf(prefix, text, maxLines) {
  const lines = text.split("\n");
  const shown = lines.slice(0, maxLines).map(l => prefix + " " + clip(l));
  if (lines.length > maxLines) {
    shown.push(`${prefix} … (${lines.length - maxLines} more lines)`);
  }
  return shown.join("\n");
}

function makeDiffPreview(oldStr, newStr, maxLines = 100) {
  return sideOf("-", oldStr, maxLines) + "\n" + sideOf("+", newStr, maxLines);
}

function previewContent(content, maxLines = 200) {
  const lines = String(content).split("\n");
  const shown = lines.slice(0, maxLines).map(l => "  | " + clip(l));
  if (lines.length > maxLines) shown.push(`  | … (${lines.length - maxLines} more lines)`);
  return shown.join("\n");
}

// Commands whose first word means "never offer always-allow", even without
// a risky pattern: they delete, overwrite, signal or change permissions.
// Programs that are never automatic, whatever the policy says.
const AUTO_BLOCKED_PROGRAMS = new Set([
  "rm", "rmdir", "mv", "cp", "dd", "kill", "killall", "pkill", "shutdown",
  "reboot", "sudo", "su", "chmod", "chown", "ln", "truncate", "shred", "mkfs",
  "mount", "umount", "eval", "exec", "source", ".", "sh", "bash", "zsh", "env",
  "xargs", "nohup", "setsid", "ssh", "scp", "curl", "wget", "nc",
]);

// Programs that never get a broad "Always" session grant. Interpreters and
// runners execute arbitrary code, and git has aliases and -c config that can do
// anything. A user can still allow such a program explicitly in policy.json.
const NEVER_SESSION_ALLOW = new Set([
  ...AUTO_BLOCKED_PROGRAMS,
  "node", "python", "python3", "perl", "ruby", "php", "deno", "bun", "npx", "make", "gcc", "go", "cargo",
  "git",
]);


// Returns { category, label } if "always allow for this session" may be
// offered for this command, otherwise null. Granularity is the first word,
// so allowing `npm` does not allow `git`.
const RISKY_SUBCOMMANDS = new Set([
  "run", "exec", "x", "dlx", "start", "test:watch",
  "install", "i", "add", "update", "upgrade", "publish", "deploy", "push", "pull",
  "fetch", "clone", "remote", "login", "logout", "token", "config", "link", "unlink",
  "reset", "clean", "checkout", "rebase", "sync",
]);

function sessionCategoryFor(command, envName = "termux") {
  if (DANGEROUS_PATTERNS.some(re => re.test(command))) return null;
  const tokens = command.trim().split(/\s+/);
  const first = tokens[0] || "";
  if (!first || NEVER_SESSION_ALLOW.has(first)) return null;
  // A grant for "npm" must not cover "npm install"; the same for git remotes.
  if (tokens.slice(1, 4).some(t => RISKY_SUBCOMMANDS.has(t))) return null;
  return {
    category: `exec:${envName}:${first}`,
    label: `'${first}' commands (${envName})`,
  };
}

function isPrivateV4(ip) {
  const [a, b] = ip.split(".").map(Number);
  if (a === 0 || a === 10 || a === 127) return true;
  if (a === 100 && b >= 64 && b <= 127) return true;
  if (a === 169 && b === 254) return true;
  if (a === 172 && b >= 16 && b <= 31) return true;
  if (a === 192 && b === 168) return true;
  if (a === 192 && b === 0) return true;
  if (a === 198 && (b === 18 || b === 19)) return true;
  return a >= 224;
}

// True if the address must NOT be fetched (loopback, private, link-local,
// multicast, or anything that is not a valid IP).
function isPrivateAddress(ip) {
  const kind = net.isIP(ip);
  if (kind === 4) return isPrivateV4(ip);
  if (kind !== 6) return true;

  const lower = ip.toLowerCase();
  const translated = lower.match(/^::ffff:0:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
  if (translated) {
    const a = parseInt(translated[1], 16), b = parseInt(translated[2], 16);
    return isPrivateV4(`${a >> 8}.${a & 255}.${b >> 8}.${b & 255}`);
  }
  const dotted = lower.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
  if (dotted) return isPrivateV4(dotted[1]);
  const hex = lower.match(/^::ffff:([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
  if (hex) {
    const a = parseInt(hex[1], 16), b = parseInt(hex[2], 16);
    return isPrivateV4(`${a >> 8}.${a & 255}.${b >> 8}.${b & 255}`);
  }
  if (lower === "::" || lower === "::1") return true;
  const compat = lower.match(/^::([0-9a-f]{1,4}):([0-9a-f]{1,4})$/);
  if (compat) {
    const a = parseInt(compat[1], 16), b = parseInt(compat[2], 16);
    return isPrivateV4(`${a >> 8}.${a & 255}.${b >> 8}.${b & 255}`);
  }
  const sixToFour = lower.match(/^2002:([0-9a-f]{1,4}):([0-9a-f]{1,4})(:|$)/);
  if (sixToFour) {
    const a = parseInt(sixToFour[1], 16), b = parseInt(sixToFour[2], 16);
    if (isPrivateV4(`${a >> 8}.${a & 255}.${b >> 8}.${b & 255}`)) return true;
  }
  if (lower.startsWith("64:ff9b:")) return true;
  const first = parseInt(lower.split(":")[0] || "0", 16);
  if ((first & 0xfe00) === 0xfc00) return true;
  if ((first & 0xffc0) === 0xfe80) return true;
  return (first & 0xff00) === 0xff00;
}

// Linear-time HTML to text. No regexes that backtrack on hostile input.
function removeBlocks(html, open, close) {
  const lower = html.toLowerCase();
  let out = "", i = 0;
  for (;;) {
    const s = lower.indexOf(open, i);
    if (s < 0) { out += html.slice(i); break; }
    out += html.slice(i, s);
    const e = lower.indexOf(close, s + open.length);
    if (e < 0) break;
    i = e + close.length;
  }
  return out;
}

function stripTags(html) {
  let out = "", i = 0;
  for (;;) {
    const s = html.indexOf("<", i);
    if (s < 0) { out += html.slice(i); break; }
    out += html.slice(i, s);
    const e = html.indexOf(">", s + 1);
    if (e < 0) break;
    const tag = html.slice(s + 1, e).trim().toLowerCase();
    out += /^\/?(br|p|div|li|tr|h[1-6])(\s|\/|$)/.test(tag) ? "\n" : " ";
    i = e + 1;
  }
  return out;
}

function htmlToText(html) {
  let h = String(html).slice(0, 500000);
  h = removeBlocks(h, "<script", "</script>");
  h = removeBlocks(h, "<style", "</style>");
  h = removeBlocks(h, "<!--", "-->");
  return stripTags(h)
    .replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, "&")
    .replace(/[ \t]+/g, " ")
    .replace(/ ?\n ?/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

// ---------- Trusted-workspace policy (user-written, optional) ----------
//
// Lets routine work run without a prompt. It can only ever ADD automatic
// allowances for things that are not already hard-blocked:
//   - hard blocks (DANGEROUS_PATTERNS, protected names, NEVER_SESSION_ALLOW,
//     path confinement) are checked before this and cannot be overridden here
//   - deletes, installs, network and git push always ask

const POLICY_DEFAULTS = Object.freeze({
  // Off unless the user turns it on: with no policy file, every edit asks.
  auto_edit: false,                // create/edit/multi-edit inside the project
  auto_exec_prefixes: [],          // e.g. ["npm test", "node ", "git status"]
  auto_fetch_hosts: [],            // e.g. ["docs.python.org"]
});

// Validates the user's policy file. Unknown keys and wrong types are rejected
// so a typo cannot silently widen anything.
function parsePolicy(raw) {
  if (raw === undefined || raw === null) return { ...POLICY_DEFAULTS, auto_exec_prefixes: [], auto_fetch_hosts: [] };
  let obj;
  try { obj = typeof raw === "string" ? JSON.parse(raw) : raw; } catch { throw new PolicyError("policy_invalid_json"); }
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) throw new PolicyError("policy_invalid");

  const allowed = new Set(Object.keys(POLICY_DEFAULTS));
  for (const k of Object.keys(obj)) if (!allowed.has(k)) throw new PolicyError("policy_unknown_key:" + k);

  const out = { ...POLICY_DEFAULTS, auto_exec_prefixes: [], auto_fetch_hosts: [] };
  if (obj.auto_edit !== undefined) {
    if (typeof obj.auto_edit !== "boolean") throw new PolicyError("policy_invalid");
    out.auto_edit = obj.auto_edit;
  }
  for (const key of ["auto_exec_prefixes", "auto_fetch_hosts"]) {
    if (obj[key] !== undefined) {
      if (!Array.isArray(obj[key]) || obj[key].length > 100 ||
          !obj[key].every(v => typeof v === "string" && v.length >= 1 && v.length <= 200)) {
        throw new PolicyError("policy_invalid");
      }
      out[key] = obj[key].slice();
    }
  }
  return out;
}

// Decide whether a request may skip the prompt. Returns { auto: true, why }
// or { auto: false, why }. Pure: no I/O.
function policyAllows(policy, req) {
  if (req.kind === "edit") {
    return policy.auto_edit
      ? { auto: true, why: "edit inside project (policy)" }
      : { auto: false, why: "edits need approval (policy)" };
  }

  if (req.kind === "exec") {
    const cmd = String(req.command || "").trim();
    if (!cmd) return { auto: false, why: "empty command" };
    if (DANGEROUS_PATTERNS.some(re => re.test(cmd))) return { auto: false, why: "risky pattern" };
    const first = cmd.split(/\s+/)[0];
    if (AUTO_BLOCKED_PROGRAMS.has(first)) return { auto: false, why: "never auto-allowed" };
    if (/\b(install|i|add|update|upgrade|publish|deploy|push|pull|fetch|clone|remote|login|token|config|reset|clean|checkout|rebase)\b/.test(cmd)) {
      return { auto: false, why: "installs, publishing and pushes always ask" };
    }
    for (const prefix of policy.auto_exec_prefixes) {
      const p = prefix.trim();
      if (cmd === p || cmd.startsWith(p + " ") || (p.endsWith(" ") && cmd.startsWith(p))) {
        return { auto: true, why: `matches policy prefix "${p}"` };
      }
    }
    return { auto: false, why: "not in policy prefixes" };
  }

  if (req.kind === "fetch") {
    const host = String(req.host || "").toLowerCase();
    if (host && policy.auto_fetch_hosts.map(h => h.toLowerCase()).includes(host)) {
      return { auto: true, why: `host ${host} allowed by policy` };
    }
    return { auto: false, why: "host not in policy" };
  }

  return { auto: false, why: "unknown request kind" };
}

class PolicyError extends Error {
  constructor(code) {
    super(code);
    this.name = "PolicyError";
    this.code = code;
  }
}

module.exports = {
  parsePolicy,
  policyAllows,
  POLICY_DEFAULTS,
  SKIP_DIRS,
  PROTECTED_NAMES,
  globToRegExp,
  sanitizeForTerminal,
  makeDiffPreview,
  previewContent,
  sessionCategoryFor,
  isPrivateAddress,
  htmlToText,
  resolveInside,
  isProtected,
  classifyCommand,
  ApprovalQueue,
  PolicyError,
  SAFE_COMMANDS,
  DANGEROUS_PATTERNS,
};
