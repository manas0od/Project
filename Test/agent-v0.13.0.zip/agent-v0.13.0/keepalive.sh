#!/data/data/com.termux/files/usr/bin/sh
# Run the CFB agent with a wake lock and restart it if it exits.
#
# Limits, stated plainly:
#  - A wake lock keeps the CPU awake. It does NOT stop Android from killing
#    Termux or its child processes. On Android 12+ the phantom-process killer
#    can still do that, so also disable battery optimisation for Termux
#    (Settings > Apps > Termux > Battery > Unrestricted) and lock Termux in
#    the recent-apps view.
#  - If Termux itself is killed, this loop dies with it. Nothing inside Termux
#    can restart Termux.

cd "$(dirname "$0")" || { echo "agent folder not found"; exit 1; }

if command -v termux-wake-lock >/dev/null 2>&1; then
  termux-wake-lock
  echo "wake lock held"
else
  echo "termux-wake-lock not found: install with: pkg install termux-api (and the Termux:API app)"
fi

trap 'echo; echo "stopping"; termux-wake-unlock 2>/dev/null; exit 0' INT TERM

while true; do
  node agent.js
  code=$?
  echo "agent exited with code $code; restarting in 5 s (Ctrl+C to stop)"
  sleep 5
done
