"use strict";
// Policy file loading and notification-button approvals. Each case runs the real
// agent in a child process with its own HOME, so the startup policy load is real.
const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");

const ROOT = fs.mkdtempSync(path.join(os.tmpdir(), "cfb-policy-"));
const AGENT = path.join(__dirname, "agent.js");
let passed = 0, failed = 0;
const ok = (name, cond, detail) => {
  if (cond) passed++; else failed++;
  console.log((cond ? "PASS " : "FAIL ") + name + (cond ? "" : " -> " + String(detail).slice(0, 300)));
};

function makeHome(name, policy) {
  const home = path.join(ROOT, name);
  fs.mkdirSync(path.join(home, ".cfb"), { recursive: true, mode: 0o700 });
  fs.writeFileSync(path.join(home, ".cfb", "bridge.token"), "t\n", { mode: 0o600 });
  if (policy !== undefined) fs.writeFileSync(path.join(home, ".cfb", "policy.json"), policy);
  return home;
}

// Runs `body` inside a child agent process. body gets { handleAction, setApprover, prompts }.
function runAgent(home, body, extraEnv = {}, vars = {}) {
  const script = `
    const fs = require("fs"), path = require("path");
    const mod = require(${JSON.stringify(AGENT)});
    const { handleAction, setApprover } = mod;
    const prompts = [];
    const vars = ${JSON.stringify(vars)};
    setApprover(async q => { prompts.push(q); return false; });
    (async () => {
      try {
        const out = await (${body})({ handleAction, setApprover, prompts, fs, path, vars, mod });
        console.log("RESULT " + JSON.stringify({ out, prompts }));
      } catch (e) { console.log("RESULT " + JSON.stringify({ error: String(e.stack || e) })); }
      process.exit(0);
    })();`;
  const r = spawnSync("node", ["-e", script], {
    encoding: "utf8", timeout: 30000,
    env: { PATH: process.env.PATH, HOME: home, CFB_PROJECT_ROOT: path.join(home, "work"),
           CFB_APPROVAL_TIMEOUT_MS: "1500", CFB_NOTIFY: "0", ...extraEnv },
  });
  const line = (r.stdout || "").split("\n").find(l => l.startsWith("RESULT "));
  return { status: r.status, stderr: r.stderr, result: line ? JSON.parse(line.slice(7)) : null };
}

// ---- policy file validation: fail closed ----
{
  const home = makeHome("badjson", "{not json");
  const r = runAgent(home, () => null);
  ok("invalid policy JSON: agent refuses to start", r.status === 1 && /invalid/.test(r.stderr), r.stderr);
}
{
  const home = makeHome("typo", JSON.stringify({ auto_exec_prefix: ["npm"] }));
  const r = runAgent(home, () => null);
  ok("policy typo key: agent refuses to start", r.status === 1 && /invalid/.test(r.stderr), r.stderr);
}

// ---- policy effects ----
const policy = JSON.stringify({ auto_edit: true, auto_exec_prefixes: ["echo", "node "], auto_fetch_hosts: [] });
{
  const home = makeHome("allow", policy);
  const r = runAgent(home, async ({ handleAction, prompts }) => {
    const write = await handleAction("file_write", { path: "a.txt", content: "hi\n" });
    const exec = await handleAction("exec", { command: "echo ok" });
    const chained = await handleAction("exec", { command: "echo ok; rm -rf work" });
    const rm = await handleAction("file_delete", { path: "a.txt" });
    const del = await handleAction("exec", { command: "rm -rf work" });
    return { write, exec, chained, rm, del, promptCount: prompts.length };
  });
  const o = r.result?.out || {};
  ok("policy: file write runs with no prompt", o.write?.ok === true, o.write);
  ok("policy: allowlisted exec runs with no prompt", o.exec?.exit_code === 0, o.exec);
  ok("policy: chained command still asks (denied by prompt)", o.chained?.error === "denied_by_user", o.chained);
  ok("policy: delete still asks (denied by prompt)", o.rm?.error === "denied_by_user", o.rm);
  ok("policy: rm -rf still asks (denied by prompt)", o.del?.error === "denied_by_user", o.del);
  ok("policy: exactly 3 prompts were shown (chained, delete, rm)", o.promptCount === 3, o.promptCount);
  const audit = fs.readFileSync(path.join(home, ".cfb", "audit.log"), "utf8");
  ok("policy: automatic approvals are audited with a reason", /"kind":"policy-auto".*matches policy prefix/.test(audit) && /"kind":"policy-auto".*edit inside project/.test(audit), audit.slice(0, 300));
}
{
  const home = makeHome("noedit", JSON.stringify({ auto_exec_prefixes: ["echo"] }));
  const r = runAgent(home, async ({ handleAction, prompts }) => {
    const w = await handleAction("file_write", { path: "b.txt", content: "x" });
    return { w, prompts: prompts.length };
  });
  ok("policy without auto_edit: edits still ask", r.result?.out?.w?.error === "denied_by_user" && r.result.out.prompts === 1, r.result);
}
{
  const home = makeHome("nofile");
  const r = runAgent(home, async ({ handleAction, prompts }) => {
    await handleAction("file_write", { path: "c.txt", content: "x" });
    return { prompts: prompts.length };
  });
  ok("no policy file: every edit asks", r.result?.out?.prompts === 1, r.result);
}

// ---- notification-button approvals ----
function notifyHome(name) {
  const home = makeHome(name);
  const log = path.join(home, "notify.log");
  const mock = path.join(home, "termux-notification");
  fs.writeFileSync(mock, `#!/bin/sh\necho "$0 $@" >> "${log}"\n`, { mode: 0o755 });
  return { home, log, mock };
}
const env = (n) => ({ CFB_NOTIFY: "1", CFB_NOTIFY_CMD: n.mock, CFB_NOTIFY_REMOVE_CMD: n.mock });

{
  // A one-line request (a delete) can be approved from the notification.
  const n = notifyHome("notify-yes");
  const r = runAgent(n.home, async ({ handleAction, setApprover, fs, path, vars }) => {
    setApprover(() => new Promise(() => {}));
    fs.mkdirSync(path.join(vars.home, "work"), { recursive: true });
    fs.writeFileSync(path.join(vars.home, "work", "tap.txt"), "bye");
    const pending = handleAction("file_delete", { path: "tap.txt" });
    await new Promise(res => setTimeout(res, 800));
    fs.writeFileSync(path.join(vars.home, ".cfb", "approvals", "ap1.answer"), "y");
    const res = await pending;
    return { res, gone: !fs.existsSync(path.join(vars.home, "work", "tap.txt")) };
  }, { ...env(n), CFB_APPROVAL_TIMEOUT_MS: "8000" }, { home: n.home });
  const log = fs.existsSync(n.log) ? fs.readFileSync(n.log, "utf8") : "";
  ok("notify: Allow tap on a one-line request deletes the file", r.result?.out?.res?.ok === true && r.result.out.gone === true, r.result);
  ok("notify: notification carries id, title and buttons", /--id cfb-ap1/.test(log) && /--button1 Allow/.test(log) && /--button2 Deny/.test(log), log);
  ok("notify: button action targets the request's answer file only", log.includes(path.join(n.home, ".cfb", "approvals", "ap1.answer")), log);
  ok("notify: notification removed after the decision", /cfb-ap1/.test(log.split("\n").filter(l => l.includes("notification-remove") || l.includes("cfb-ap1")).join("\n")), log);
  const audit = fs.readFileSync(path.join(n.home, ".cfb", "audit.log"), "utf8");
  ok("notify: audit records source=notification", /"source":"notification"/.test(audit), audit.slice(0, 300));
}
{
  // Multi-line requests (file contents, diffs) must NOT be approvable from a notification.
  const n = notifyHome("notify-multiline");
  const r = runAgent(n.home, async ({ handleAction, setApprover }) => {
    setApprover(async () => false); // terminal says no; the point is that no notification was shown
    return { res: await handleAction("file_write", { path: "m.txt", content: "line one\nline two" }) };
  }, { ...env(n), CFB_APPROVAL_TIMEOUT_MS: "1500" });
  const log = fs.existsSync(n.log) ? fs.readFileSync(n.log, "utf8") : "";
  ok("notify: multi-line write shows no notification (terminal only)", !/--id cfb-/.test(log), log);
  ok("notify: and was denied by the terminal answer", r.result?.out?.res?.error === "denied_by_user", r.result);
}
{
  const n = notifyHome("notify-no");
  const r = runAgent(n.home, async ({ handleAction, setApprover, fs, path, vars }) => {
    setApprover(() => new Promise(() => {}));
    fs.mkdirSync(path.join(vars.home, "work"), { recursive: true });
    fs.writeFileSync(path.join(vars.home, "work", "keep.txt"), "keep");
    const pending = handleAction("file_delete", { path: "keep.txt" });
    await new Promise(res => setTimeout(res, 800));
    fs.writeFileSync(path.join(vars.home, ".cfb", "approvals", "ap1.answer"), "n");
    const res = await pending;
    return { res, kept: fs.existsSync(path.join(vars.home, "work", "keep.txt")) };
  }, { ...env(n), CFB_APPROVAL_TIMEOUT_MS: "8000" }, { home: n.home });
  ok("notify: Deny tap denies and keeps the file", r.result?.out?.res?.error === "denied_by_user" && r.result.out.kept === true, r.result);
}
{
  const n = notifyHome("notify-junk");
  const r = runAgent(n.home, async ({ handleAction, setApprover, fs, path, vars }) => {
    setApprover(() => new Promise(() => {}));
    fs.mkdirSync(path.join(vars.home, "work"), { recursive: true });
    fs.writeFileSync(path.join(vars.home, "work", "j.txt"), "j");
    const pending = handleAction("file_delete", { path: "j.txt" });
    await new Promise(res => setTimeout(res, 800));
    fs.writeFileSync(path.join(vars.home, ".cfb", "approvals", "ap1.answer"), "yes please, always");
    return { res: await pending };
  }, { ...env(n), CFB_APPROVAL_TIMEOUT_MS: "8000" }, { home: n.home });
  ok("notify: any answer other than exact y/n/a is a denial", r.result?.out?.res?.error === "denied_by_user", r.result);
}
{
  const n = notifyHome("notify-always-no-offer");
  const r = runAgent(n.home, async ({ handleAction, setApprover, fs, path, vars }) => {
    setApprover(() => new Promise(() => {}));
    fs.mkdirSync(path.join(vars.home, "work"), { recursive: true });
    fs.writeFileSync(path.join(vars.home, "work", "x"), "x");
    const pending = handleAction("file_delete", { path: "x" });
    await new Promise(res => setTimeout(res, 800));
    fs.writeFileSync(path.join(vars.home, ".cfb", "approvals", "ap1.answer"), "a");
    return { res: await pending };
  }, { ...env(n), CFB_APPROVAL_TIMEOUT_MS: "8000" }, { home: n.home });
  const log = fs.existsSync(n.log) ? fs.readFileSync(n.log, "utf8") : "";
  ok("notify: deletes never offer an Always button", !/--button3/.test(log), log);
  ok("notify: 'a' answer on a no-always prompt is a denial", r.result?.out?.res?.error === "denied_by_user", r.result);
}
{
  const n = notifyHome("notify-stale");
  fs.mkdirSync(path.join(n.home, ".cfb", "approvals"), { recursive: true });
  fs.writeFileSync(path.join(n.home, ".cfb", "approvals", "ap1.answer"), "y");
  const r = runAgent(n.home, async ({ handleAction, setApprover, fs, path, vars }) => {
    setApprover(() => new Promise(() => {}));
    fs.mkdirSync(path.join(vars.home, "work"), { recursive: true });
    fs.writeFileSync(path.join(vars.home, "work", "s.txt"), "x");
    return { res: await handleAction("file_delete", { path: "s.txt" }) };
  }, { ...env(n), CFB_APPROVAL_TIMEOUT_MS: "1500" }, { home: n.home });
  ok("notify: an answer left from a previous run cannot approve a new request", r.result?.out?.res?.error === "denied_by_user", r.result);
}

// ---- cancellation from the Worker ----
{
  const home = makeHome("cancel");
  const r = runAgent(home, async ({ handleAction, setApprover, mod }) => {
    setApprover(async () => true);
    const run = mod.requestScope.run({ requestId: "rqA" }, () => handleAction("exec", { command: "sleep 30" }));
    await new Promise(res => setTimeout(res, 400));
    const t0 = Date.now();
    const stopped = mod.cancelRequest("rqA");
    const res = await run;
    return { stopped, res, took: Date.now() - t0 };
  });
  const o = r.result?.out || {};
  ok("cancel: running command is killed", o.stopped >= 1 && o.res?.signal === "SIGKILL", r.result);
  ok("cancel: returns quickly, not after 30 s", o.took < 3000, o.took);
}
{
  const home = makeHome("cancel-prompt");
  const r = runAgent(home, async ({ handleAction, setApprover, mod, fs, path, vars }) => {
    let answerNext = null;
    setApprover(() => new Promise(res => { answerNext = res; }));
    const run = mod.requestScope.run({ requestId: "rqB" }, () => handleAction("file_write", { path: "c.txt", content: "x" }));
    await new Promise(res => setTimeout(res, 300));
    mod.cancelRequest("rqB");
    const res = await run;
    // The agent must still work afterwards: the next prompt gets its own answer.
    setApprover(async () => true);
    const after = await handleAction("file_write", { path: "d.txt", content: "y" });
    return { res, cancelledWrote: fs.existsSync(path.join(vars.home, "work", "c.txt")), after };
  }, {}, { home });
  const o = r.result?.out || {};
  ok("cancel: pending approval is released as a denial", o.res?.error === "denied_by_user", o.res);
  ok("cancel: cancelled write never happens", o.cancelledWrote === false, o);
  ok("cancel: later prompts are not blocked or misanswered", o.after?.ok === true, o.after);
}
{
  const home = makeHome("cancel-scope");
  const r = runAgent(home, async ({ handleAction, setApprover, mod }) => {
    setApprover(async () => true);
    const a = mod.requestScope.run({ requestId: "rqC" }, () => handleAction("exec", { command: "sleep 2; echo survived" }));
    await new Promise(res => setTimeout(res, 200));
    const stopped = mod.cancelRequest("someone-else");
    return { stopped, res: await a };
  });
  const o = r.result?.out || {};
  ok("cancel: cancelling another request touches nothing", o.stopped === 0 && /survived/.test(o.res?.output || ""), o);
}

console.log(`\n${passed} passed, ${failed} failed`);
fs.rmSync(ROOT, { recursive: true, force: true });
process.exit(failed ? 1 : 0);
