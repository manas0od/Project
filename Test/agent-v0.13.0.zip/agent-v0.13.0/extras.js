"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const http = require("http");
const https = require("https");
const dns = require("dns");
const net = require("net");
const { spawn, spawnSync } = require("child_process");
const G = require("./gate");

const JOB_ID = /^[a-f0-9]{12}$/;
const sleep = ms => new Promise(r => setTimeout(r, ms));

function intIn(value, min, max, fallback) {
  return Number.isInteger(value) ? Math.min(Math.max(value, min), max) : fallback;
}

function createExtras(ctx) {
  const {
    getProjectRoot, JOBS_DIR, SH, requireApproval, buildSpawnSpec,
    prootAvailable, audit, fileError, atomicWrite,
  } = ctx;

  const root = () => getProjectRoot();
  const rel = p => path.relative(root(), p) || ".";

  // Replaceable in tests only. Returns true when an address must be blocked.
  let addressBlocked = G.isPrivateAddress;
  function setAddressPolicy(fn) { addressBlocked = fn; }

  // ---------- multi-edit ----------

  async function multiEdit(payload) {
    const edits = payload.edits;
    if (!Array.isArray(edits) || edits.length < 1 || edits.length > 20) {
      return { ok: false, error: "edits_required" };
    }
    let total = 0;
    for (const e of edits) {
      if (!e || typeof e.old_str !== "string" || e.old_str.length === 0 || typeof e.new_str !== "string") {
        return { ok: false, error: "invalid_edit" };
      }
      total += e.old_str.length + e.new_str.length;
    }
    if (total > 16000) return { ok: false, error: "edits_too_large" };

    try {
      const target = G.resolveInside(root(), payload.path);
      const original = fs.readFileSync(target, "utf8");
      let text = original;

      for (let i = 0; i < edits.length; i++) {
        const count = text.split(edits[i].old_str).length - 1;
        if (count === 0) return { ok: false, error: "old_str_not_found", edit_index: i };
        if (count > 1) return { ok: false, error: "old_str_not_unique", edit_index: i, occurrences: count };
        text = text.replace(edits[i].old_str, () => edits[i].new_str);
      }

      const previews = edits
        .map((e, i) => `#${i + 1}\n${G.makeDiffPreview(e.old_str, e.new_str, 4)}`)
        .join("\n");
      const approved = await requireApproval(
        `MULTI-EDIT ${rel(target)} (${edits.length} edits, applied together)\n${previews}`,
        { category: "edit", label: "file edits inside the project", policyReq: { kind: "edit" } }
      );
      if (!approved) return { ok: false, error: "denied_by_user" };

      // Re-read: the file may have changed while the prompt was open.
      if (fs.readFileSync(target, "utf8") !== original) {
        return { ok: false, error: "file_changed_during_approval" };
      }
      atomicWrite(target, text);
      return { ok: true, path: rel(target), edits_applied: edits.length };
    } catch (error) {
      return fileError(error);
    }
  }

  // ---------- search ----------

  function grepTool(payload) {
    const pattern = payload.pattern;
    if (typeof pattern !== "string" || pattern.length < 1 || pattern.length > 300) {
      return { ok: false, error: "invalid_pattern" };
    }

    try {
      const target = G.resolveInside(root(), payload.path || ".");
      const globRe = payload.glob !== undefined ? G.globToRegExp(payload.glob) : null;
      const globHasSlash = typeof payload.glob === "string" && payload.glob.includes("/");
      const max = intIn(payload.max_results, 1, 200, 100);

      const args = ["-rnIE", "-m", "50"];
      if (payload.ignore_case === true) args.push("-i");
      for (const d of G.SKIP_DIRS) args.push(`--exclude-dir=${d}`);
      for (const n of G.PROTECTED_NAMES) args.push(`--exclude=${n}`);
      args.push("-e", pattern, "--", target);

      const r = spawnSync("grep", args, {
        encoding: "utf8", timeout: 10000, maxBuffer: 4 * 1024 * 1024,
      });
      if (r.error) {
        return { ok: false, error: r.error.code === "ENOENT" ? "grep_not_installed" : "grep_failed" };
      }
      if (r.status === 2 && !r.stdout) {
        return { ok: false, error: "invalid_pattern", detail: (r.stderr || "").split("\n")[0].slice(0, 200) };
      }

      const matches = [];
      let budget = 20000, truncated = false;
      for (const line of (r.stdout || "").split("\n")) {
        const m = line.match(/^(.*?):(\d+):(.*)$/);
        if (!m) continue;
        const file = path.relative(root(), m[1]);
        if (file.startsWith("..") || G.isProtected(root(), path.resolve(root(), file))) continue;
        if (globRe) {
          const hit = globRe.test(file) || (!globHasSlash && globRe.test(path.basename(file)));
          if (!hit) continue;
        }
        const text = m[3].length > 300 ? m[3].slice(0, 300) + "…" : m[3];
        budget -= text.length + file.length;
        if (matches.length >= max || budget < 0) { truncated = true; break; }
        matches.push({ path: file, line: Number(m[2]), text });
      }
      return { ok: true, matches, count: matches.length, truncated };
    } catch (error) {
      return fileError(error);
    }
  }

  function globTool(payload) {
    try {
      const base = G.resolveInside(root(), payload.path || ".");
      const re = G.globToRegExp(payload.pattern);
      const hasSlash = payload.pattern.includes("/");
      const max = intIn(payload.max_results, 1, 500, 200);

      const found = [];
      let visited = 0, capped = false;
      const walk = (dir, depth) => {
        if (depth > 20 || capped) return;
        let entries;
        try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
        for (const e of entries) {
          if (++visited > 20000) { capped = true; return; }
          if (e.isSymbolicLink()) continue;            // never follow links
          const full = path.join(dir, e.name);
          if (e.isDirectory()) {
            if (!G.SKIP_DIRS.has(e.name)) walk(full, depth + 1);
          } else if (e.isFile()) {
            if (G.isProtected(root(), full)) continue;
            const r = path.relative(base, full).split(path.sep).join("/");
            if (re.test(r) || (!hasSlash && re.test(e.name))) {
              let mtime = 0;
              try { mtime = fs.statSync(full).mtimeMs; } catch {}
              found.push({ path: path.relative(root(), full), mtime });
            }
          }
        }
      };
      walk(base, 0);

      found.sort((a, b) => b.mtime - a.mtime);
      return {
        ok: true,
        files: found.slice(0, max).map(f => f.path),
        count: Math.min(found.length, max),
        truncated: found.length > max || capped,
      };
    } catch (error) {
      return fileError(error);
    }
  }

  // ---------- web fetch ----------

  function fetchOnce(urlObj, timeoutMs, maxBytes) {
    return new Promise((resolve, reject) => {
      const lib = urlObj.protocol === "https:" ? https : http;
      let settled = false;
      const done = (err, val) => {
        if (settled) return;
        settled = true;
        if (err) reject(err); else resolve(val);
      };

      const req = lib.request(urlObj, {
        method: "GET",
        timeout: timeoutMs,
        headers: {
          "User-Agent": "CFB-agent/0.9",
          "Accept": "text/html,text/plain,application/json,*/*;q=0.5",
          "Accept-Encoding": "identity",
        },
        // The address check happens at connect time, on the address that is
        // actually used, so DNS rebinding cannot swap in a private address.
        lookup: (hostname, options, cb) => {
          const wantAll = options && options.all;
          dns.lookup(hostname, { ...options, all: true }, (err, addrs) => {
            if (err) return cb(err);
            if (!addrs.length || addrs.some(a => addressBlocked(a.address))) {
              return cb(new Error("blocked_private_address"));
            }
            if (wantAll) return cb(null, addrs);
            cb(null, addrs[0].address, addrs[0].family);
          });
        },
      }, res => {
        const chunks = [];
        let size = 0, truncated = false;
        const finish = () => done(null, {
          status: res.statusCode, headers: res.headers,
          body: Buffer.concat(chunks), truncated,
        });
        res.on("data", chunk => {
          if (truncated) return;
          size += chunk.length;
          if (size > maxBytes) {
            chunks.push(chunk.subarray(0, chunk.length - (size - maxBytes)));
            truncated = true;
            res.destroy();
            finish();
          } else {
            chunks.push(chunk);
          }
        });
        res.on("end", finish);
        res.on("close", finish);
        res.on("error", e => (truncated ? finish() : done(e)));
      });

      req.on("timeout", () => req.destroy(new Error("timeout")));
      req.on("error", done);
      req.end();
    });
  }

  async function webFetch(payload, startedAt, budgetMs) {
    if (typeof payload.url !== "string" || payload.url.length > 2000) {
      return { ok: false, error: "invalid_url" };
    }
    let urlObj;
    try { urlObj = new URL(payload.url); } catch { return { ok: false, error: "invalid_url" }; }
    if (urlObj.protocol !== "https:" && urlObj.protocol !== "http:") {
      return { ok: false, error: "unsupported_scheme" };
    }
    if (urlObj.username || urlObj.password) return { ok: false, error: "credentials_in_url_refused" };

    const maxChars = intIn(payload.max_chars, 1, 15000, 15000);
    const offset = intIn(payload.offset, 0, 10000000, 0);
    const host = urlObj.hostname.toLowerCase();

    const bare = host.replace(/^\[|\]$/g, "");
    if (net.isIP(bare) && addressBlocked(bare)) return { ok: false, error: "blocked_private_address" };

    const approved = await requireApproval(
      `FETCH ${urlObj.href}  [NETWORK]`,
      { category: `web:${host}`, label: `fetching from ${host}`, policyReq: { kind: "fetch", host } }
    );
    if (!approved) return { ok: false, error: "denied_by_user" };

    let current = urlObj, response;
    try {
      for (let hop = 0; hop <= 3; hop++) {
        const left = budgetMs - (Date.now() - startedAt);
        const timeout = Math.max(2000, Math.min(15000, left));
        response = await fetchOnce(current, timeout, 500000);

        const loc = response.headers.location;
        if ([301, 302, 303, 307, 308].includes(response.status) && loc) {
          const next = new URL(loc, current);
          if (next.hostname.toLowerCase() !== host) {
            return {
              ok: true, status: response.status, redirect_to: next.href,
              note: "Cross-host redirect not followed. Call web_fetch again with redirect_to if you want it.",
            };
          }
          if (current.protocol === "https:" && next.protocol !== "https:") {
            return { ok: false, error: "https_downgrade_refused" };
          }
          current = next;
          continue;
        }
        break;
      }
    } catch (error) {
      const msg = String(error.message || error);
      return {
        ok: false,
        error: msg.includes("blocked_private_address") ? "blocked_private_address"
          : msg === "timeout" ? "fetch_timeout" : "fetch_failed",
      };
    }

    const type = String(response.headers["content-type"] || "").toLowerCase();
    const textual = /^text\//.test(type) || /application\/(json|xml|xhtml|javascript|x-yaml|yaml)/.test(type) || /\+(json|xml)/.test(type);
    if (!textual) {
      return {
        ok: true, status: response.status, content_type: type, binary: true,
        bytes: response.body.length, note: "Non-text content is not returned.",
      };
    }

    let text = response.body.toString("utf8");
    if (type.includes("html")) text = G.htmlToText(text);
    return {
      ok: true,
      url: current.href,
      status: response.status,
      content_type: type,
      content: text.slice(offset, offset + maxChars),
      offset,
      total_chars: text.length,
      truncated: offset + maxChars < text.length || response.truncated,
      untrusted_content: true,
    };
  }

  // ---------- background jobs ----------

  const jobDir = id => path.join(JOBS_DIR, id);

  function readMeta(id) {
    return JSON.parse(fs.readFileSync(path.join(jobDir(id), "meta.json"), "utf8"));
  }

  function pidAlive(pid) {
    try { process.kill(pid, 0); } catch (e) { if (e.code !== "EPERM") return false; }
    // Guard against a recycled pid after a reboot: our wrapper's command line
    // always mentions CFB_EXIT. If /proc is unreadable, assume it is ours.
    try {
      return fs.readFileSync(`/proc/${pid}/cmdline`, "utf8").includes("CFB_EXIT");
    } catch {
      return true;
    }
  }

  function groupAlive(pgid) {
    try { process.kill(-pgid, 0); return true; } catch (e) { return e.code === "EPERM"; }
  }

  function jobState(id) {
    const dir = jobDir(id);
    const meta = readMeta(id);
    const exitFile = path.join(dir, "exit");
    const logFile = path.join(dir, "out.log");
    let status, exitCode = null, endedAt = null;

    if (fs.existsSync(exitFile)) {
      status = "exited";
      exitCode = parseInt(fs.readFileSync(exitFile, "utf8").trim(), 10);
      endedAt = fs.statSync(exitFile).mtimeMs;
    } else if (pidAlive(meta.pid)) {
      status = "running";
    } else if (fs.existsSync(path.join(dir, "killed"))) {
      status = "killed"; // stopped through job_kill
    } else {
      status = "lost"; // process gone without an exit code (killed elsewhere, or phone rebooted)
    }
    const size = fs.existsSync(logFile) ? fs.statSync(logFile).size : 0;
    return { meta, status, exitCode, logFile, size,
      runtime: Math.round(((endedAt || Date.now()) - meta.started_at) / 1000) };
  }

  async function jobStart(payload) {
    if (typeof payload.command !== "string") return { ok: false, error: "command_required" };
    const env = payload.env || "termux";
    if (env !== "termux" && env !== "ubuntu") return { ok: false, error: "invalid_env" };

    let decision, cwd;
    try {
      decision = G.classifyCommand(payload.command);
      cwd = G.resolveInside(root(), payload.cwd || ".");
    } catch (error) {
      return fileError(error);
    }
    if (env === "ubuntu" && !prootAvailable()) return { ok: false, error: "proot_distro_not_installed" };

    if (decision.level === "ask") {
      const network = /\b(curl|wget|nc|ssh|scp)\b/.test(payload.command) ? "  [NETWORK]" : "";
      const sess = G.sessionCategoryFor(payload.command, env);
      const approved = await requireApproval(
        `START BACKGROUND JOB [${env}] in ${rel(cwd)}: ${payload.command}  [${decision.reason}]${network}`,
        { ...(sess ? { category: sess.category, label: sess.label } : {}), policyReq: { kind: "exec", command: payload.command } }
      );
      if (!approved) return { ok: false, error: "denied_by_user" };
    } else {
      audit("job-allowed", payload.command);
    }

    fs.mkdirSync(JOBS_DIR, { recursive: true, mode: 0o700 });
    const id = crypto.randomBytes(6).toString("hex");
    const dir = jobDir(id);
    fs.mkdirSync(dir, { mode: 0o700 });

    const spec = buildSpawnSpec(env, cwd, payload.command);
    const exitFile = path.join(dir, "exit");
    const logFd = fs.openSync(path.join(dir, "out.log"), "a", 0o600);

    // The wrapper records the exit code even if this agent restarts later.
    const child = spawn(SH, ["-c", '"$@"; echo $? > "$CFB_EXIT"', "sh", spec.file, ...spec.args], {
      cwd: spec.cwd,
      env: { ...spec.env, CFB_EXIT: exitFile },
      detached: true,
      stdio: ["ignore", logFd, logFd],
    });
    child.on("error", () => {});
    child.unref();
    fs.closeSync(logFd);

    if (!child.pid) return { ok: false, error: "spawn_failed" };

    fs.writeFileSync(path.join(dir, "meta.json"), JSON.stringify({
      id, command: payload.command, cwd: rel(cwd), env,
      started_at: Date.now(), pid: child.pid,
    }), { mode: 0o600 });

    return { ok: true, job_id: id, pid: child.pid };
  }

  function jobPoll(payload) {
    if (!JOB_ID.test(String(payload.job_id))) return { ok: false, error: "invalid_job_id" };
    try {
      const j = jobState(payload.job_id);
      let tail = "";
      if (j.size > 0) {
        const len = Math.min(j.size, 1500);
        const fd = fs.openSync(j.logFile, "r");
        const buf = Buffer.alloc(len);
        fs.readSync(fd, buf, 0, len, j.size - len);
        fs.closeSync(fd);
        tail = buf.toString("utf8");
      }
      return {
        ok: true, job_id: payload.job_id, status: j.status, exit_code: j.exitCode,
        command: j.meta.command, runtime_seconds: j.runtime, log_bytes: j.size, tail,
      };
    } catch (error) {
      return error.code === "ENOENT" ? { ok: false, error: "job_not_found" } : fileError(error);
    }
  }

  function jobLog(payload) {
    if (!JOB_ID.test(String(payload.job_id))) return { ok: false, error: "invalid_job_id" };
    try {
      const j = jobState(payload.job_id);
      const offset = intIn(payload.offset, 0, Number.MAX_SAFE_INTEGER, 0);
      const limit = intIn(payload.limit, 1, 15000, 15000);
      const len = Math.max(0, Math.min(limit, j.size - offset));
      const buf = Buffer.alloc(len);
      if (len > 0) {
        const fd = fs.openSync(j.logFile, "r");
        fs.readSync(fd, buf, 0, len, offset);
        fs.closeSync(fd);
      }
      return {
        ok: true, content: buf.toString("utf8"), offset,
        next_offset: offset + len, size: j.size, eof: offset + len >= j.size,
        status: j.status,
      };
    } catch (error) {
      return error.code === "ENOENT" ? { ok: false, error: "job_not_found" } : fileError(error);
    }
  }

  function jobList() {
    if (!fs.existsSync(JOBS_DIR)) return { ok: true, jobs: [] };
    const jobs = [];
    for (const id of fs.readdirSync(JOBS_DIR)) {
      if (!JOB_ID.test(id)) continue;
      try {
        const j = jobState(id);
        jobs.push({
          job_id: id, status: j.status, exit_code: j.exitCode,
          command: j.meta.command.slice(0, 120), started_at: j.meta.started_at,
        });
      } catch {}
    }
    jobs.sort((a, b) => b.started_at - a.started_at);
    return { ok: true, jobs: jobs.slice(0, 30) };
  }

  async function jobKill(payload) {
    if (!JOB_ID.test(String(payload.job_id))) return { ok: false, error: "invalid_job_id" };
    let j;
    try { j = jobState(payload.job_id); } catch { return { ok: false, error: "job_not_found" }; }
    if (j.status !== "running") return { ok: false, error: "not_running" };

    const approved = await requireApproval(
      `KILL background job ${payload.job_id}: ${j.meta.command.slice(0, 200)}`
    );
    if (!approved) return { ok: false, error: "denied_by_user" };

    fs.writeFileSync(path.join(jobDir(payload.job_id), "killed"), "1", { mode: 0o600 });
    try { process.kill(-j.meta.pid, "SIGTERM"); } catch {}
    await sleep(2000);
    // A child in the group may ignore SIGTERM after the leader has exited, so
    // check the group, not just the leader.
    if (groupAlive(j.meta.pid)) {
      try { process.kill(-j.meta.pid, "SIGKILL"); } catch {}
      await sleep(300);
    }
    return { ok: true, killed: !groupAlive(j.meta.pid) };
  }

  return {
    multiEdit, grep: grepTool, glob: globTool, webFetch, setAddressPolicy,
    jobStart, jobPoll, jobLog, jobList, jobKill,
  };
}

module.exports = { createExtras };
