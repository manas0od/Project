# CFB agent (Termux), v0.13.0

Gives Claude a development environment on your phone, with an approval gate
that you control from the Termux terminal.

## Install (Termux)

    mkdir -p ~/cfb-work
    chmod 600 ~/.cfb/bridge.token          # agent refuses to start otherwise
    pkg install grep                        # file_grep uses it (usually present)
    cd agent-v0.13.0 && npm install
    npm test                                # gate + agent + policy tests, no network needed
    proot-distro login ubuntu -- mkdir -p /root/cfb-work    # only for env: "ubuntu"
    node agent.js

Deploy the Worker (worker-v0.11.0) first, then start the agent.
Stop any older agent first: two agents fight over the connection.

## Trusted-workspace policy (optional, fewer prompts)

Create ~/.cfb/policy.json to let routine work run without a prompt:

    {
      "auto_edit": true,
      "auto_exec_prefixes": ["npm test", "node ", "python3 ", "git status", "git diff", "git add", "git commit"],
      "auto_fetch_hosts": ["docs.python.org"]
    }

What the policy can and cannot do:
  - auto_edit: create, edit and multi-edit inside the project run without asking.
    Off when there is no policy file.
  - auto_exec_prefixes: whole-word prefixes. "node " covers "node app.js" but not
    "nodejs-evil". A command is still refused the automatic path if it contains a
    risky pattern (pipes, ;, &&, $(), redirects) or a never-allow program.
  - auto_fetch_hosts: exact hostnames only.
  - Never automatic, whatever the policy says: deletes, rm, sudo, git push,
    installs (npm/pip install), publish, deploy, network commands, shells, eval,
    protected files, and anything outside the project.

An invalid policy file stops the agent from starting. Unknown keys are errors,
so a typo cannot widen access. Every automatic approval is in ~/.cfb/audit.log
with the rule that allowed it.

## Approving from the notification shade (optional)

Install Termux:API (app from F-Droid or GitHub, plus `pkg install termux-api`).
When `termux-notification` is available, each approval also appears as a
notification with Allow and Deny buttons (and Always, where it is offered).
Tapping a button works without opening Termux. The terminal prompt still works,
and whichever answer arrives first wins. Set CFB_NOTIFY=0 to turn this off.

Unverified on a real phone: the button commands, notification removal, and
whether Android shows the notification while Termux is in the background.

## Keeping the agent running

    sh keepalive.sh

Runs the agent in a loop with a wake lock. It cannot stop Android from killing
Termux. See the notes at the top of keepalive.sh and disable battery
optimisation for Termux.

## Tools (23)

Read, no approval:   status, echo, file_read, file_list, file_grep, file_glob,
                     terminal_read, terminal_status, terminal_list,
                     job_poll, job_log, job_list
Ask first:           file_write, file_str_replace, file_multi_edit, file_delete,
                     exec (unless read-only allowlisted), job_start, job_kill,
                     terminal_create, terminal_write, terminal_kill, web_fetch

## Approvals

Prompts appear in the Termux terminal and show what will actually happen:
the lines being written, the old and new text of an edit, the full command,
the URL. Type `y` to allow, anything else to deny. No answer in 120 s = deny.
One prompt at a time, answered in order.

Some prompts end with `[y/N/a]`. `a` means "always allow this kind of thing
until the agent restarts":
  - file edits inside the project (write / edit / multi-edit)
  - one program, in one environment (for example `npm` in termux)
  - one website host for web_fetch
It is never offered for: deletes, kills, risky commands (rm -r, git push,
sudo, pipes, chaining, redirects, substitution), network commands, shells,
eval, or anything in the project-protection list.

Everything is recorded in ~/.cfb/audit.log (approvals, denials, auto-approvals
and unprompted read-only commands).

## What is confined

File tools and `exec` work inside ~/cfb-work (CFB_PROJECT_ROOT). Absolute paths,
`..`, and symlinks pointing outside are refused. bridge.token, .env, .netrc,
SSH/GPG keys and anything under .cfb are blocked by name.
Commands run with HOME set to the project, so ~/.ssh and saved git credentials
in your real home are not visible to them. To let git push work, set
CFB_EXEC_HOME to a directory that holds the credentials you want to expose.

This is a gate, not a sandbox. An approved command runs as your Termux user and
can reach anything that user can. The `ubuntu` environment is a convenience,
not an isolation boundary.

## Long commands

`exec` stops after about two minutes (the Worker's request window) and says
`timed_out`. Use `job_start`: it returns a job id at once, keeps running if the
connection drops or the agent restarts, and `job_poll` / `job_log` (byte-offset
cursor, re-readable) show progress and the exit code. A job that vanishes
without an exit code reports `lost` (for example after a reboot).

## web_fetch

Fetches http(s) pages from the phone. Loopback, private, link-local and
metadata addresses are refused, checked on the address actually connected to.
Cross-host redirects are reported, not followed. Page text is untrusted:
a page can contain instructions aimed at Claude. Prompt injection is the main
risk of any tool that reads outside content while it can also run commands.

## Tests

    npm test                  gate (120) + agent (95) + policy/notify/cancel (29)
    npm run test:policy       policy file, notification approvals and cancellation (29)
    npm run test:consistency  Worker and agent agree on all 23 tools, scope table and cancel route (39 checks);
                              needs worker-v0.11.0 unzipped next to this folder
    npm run test:e2e          32 checks through a LOCAL Worker; run on a PC with wrangler

## Not verified on a real phone

Real Termux prompts; Termux's shell path and environment passthrough
(PREFIX, LD_PRELOAD) with npm/pip/git; proot-distro Ubuntu itself (tested with
a stand-in); the production Worker; Claude's client behaviour on long waits;
Android killing background processes; behaviour when the disk fills (job logs
are not size-limited).

## Not provided

Plan mode and sub-agents (these live in the Claude client, not the bridge),
image and notebook readers, user-defined hooks, per-rule permission files,
and an MCP client inside the agent.

## Audit status (v0.13.0)

Second audit (v0.13.0), fixed with regression tests:
- git branch (delete, rename, force-move) and git diff/show always ask. Only git status, git log and git rev-parse run automatically.
- Shell variables ($VAR, ${VAR}) always ask, so $PREFIX/../x cannot reach outside the project.
- Environment-file variants (.env.local, .env.production, ...) and .npmrc/.pypirc are protected.
- Hard-linked files are refused: a second name for a protected file cannot be checked by name.
- Interpreters (node, python, make, npx, ...) and git never get a session "Always" grant; npm run/exec/x/dlx never do. Explicit policy prefixes can still allow a program you choose.
- Approval prompts show full diffs and content (up to 200 lines per block).
- Writes over 16,000 characters are refused by the agent as well as the Worker.
- Outputs from file, command, job, terminal and web tools carry untrusted_content: true.
- Ubuntu commands get /root as HOME. proot availability is checked without a shell.
- Killing a job checks the whole process group, not just the leader.
- IPv4-translated IPv6 (::ffff:0:a.b.c.d) is classified as private.
- Worker: every tool needs mcp:read as well as its own scope; cancel keys include the id type; cancel index entries are removed on completion.
- Approval records older than ten minutes are dropped.

Fixed, with regression tests:
- Multi-line commands (newline, carriage return, control characters) always ask.
  Previously `pwd` followed by a newline and a second command was auto-approved.
- Reads of protected names (.env, .netrc, bridge.token, SSH/GPG keys) and absolute,
  home (~) or parent (..) paths in shell commands always ask.
- Session "Always" grants never cover install, publish, push, pull, fetch, clone,
  remote, login, config, reset, clean, checkout or rebase. A grant for `npm` covers
  `npm test`, not `npm install`.
- Symlinks inside the project that point at protected files are refused.
- IPv4-compatible and 6to4 IPv6 addresses carrying private IPv4 are blocked.
- Notification buttons only approve one-line requests. Edits and multi-line
  requests are answered in Termux, where the full text is shown.
- Terminal input is shown in full (up to 3000 characters).
- Ubuntu commands get the same minimal environment as Termux commands.
- The audit log rotates at 5 MB.

Fixed in Worker v0.10.0 and agent v0.12.0:
- OAuth scopes: mcp:read, mcp:write, mcp:exec and mcp:network are separate. Each tool
  needs one, checked before the request reaches the phone. Existing connections only
  hold mcp:read: reconnect the connector and approve the new scopes to get write,
  exec or network tools. A token without a scope gets an insufficient_scope error.
- Cancellation: when Claude cancels a call, the Worker tells the agent. Waiting
  approvals are released as denials and any command the call started is killed.
  Background jobs are not cancelled (by design).

Still not fixed (second audit):
- Shell commands are not sandboxed. The gate decides whether to run; it does not limit what a running command can reach.
- OAuth scopes are checked per tool name, not per effect: mcp:exec can still write files and reach the network.
- Cancellation does not yet stop in-flight web fetches or terminal operations. Background jobs are not cancelled by design.
- Race windows remain between approval and the file operation (no descriptor-relative writes).
- Job logs have no size cap and job directories are never deleted.
- Terminal sessions still need ~/cfb/sessions.py, which is not in this package.

Earlier items still open:
- Shell commands are not sandboxed. An approved command runs as your Termux user
  and can reach anything it can. The gate decides whether to run; it does not limit
  what runs.
- Job logs have no size limit, and completed jobs are never deleted.
- The agent does not repeat the Worker's per-field limits on every path.
- Persistent terminals depend on ~/cfb/sessions.py, which is not in this package.
- Android reliability and 32-bit ARM compatibility are untested on the phone.
