"use strict";
// Cross-checks the Worker and the agent: every tool the Worker advertises must
// be accepted by both of the Worker's validators and handled by the agent, with
// nothing extra on either side.
//   node consistency.test.js [path/to/worker/src/index.js]
const fs = require("fs");
const path = require("path");

const workerPath = process.argv[2] || path.join(__dirname, "..", "worker-v0.11.0", "src", "index.js");
if (!fs.existsSync(workerPath)) {
  console.log("SKIP: Worker source not found at " + workerPath);
  console.log("      (unzip worker-v0.11.0.zip next to this folder, or pass its path)");
  process.exit(0);
}
const worker = fs.readFileSync(workerPath, "utf8");
const agent = fs.readFileSync(path.join(__dirname, "agent.js"), "utf8");

let failed = 0;
function check(name, ok, detail) {
  console.log((ok ? "PASS " : "FAIL ") + name + (ok ? "" : " -> " + detail));
  if (!ok) failed++;
}
const sameSet = (a, b) => a.length === b.length && a.every(x => b.includes(x));
const diff = (a, b) => [...a.filter(x => !b.includes(x)).map(x => "-" + x), ...b.filter(x => !a.includes(x)).map(x => "+" + x)].join(" ");

// Tools advertised in tools/list.
const listStart = worker.indexOf('data.method === "tools/list"');
const listEnd = worker.indexOf('data.method === "tools/call"');
const listed = [...worker.slice(listStart, listEnd).matchAll(/^\s{10}name: "([a-z_]+)"/gm)].map(m => m[1]);

const keysOf = block => [...block.matchAll(/^\s+([a-z_]+): \[/gm)].map(m => m[1]);
const mcpBlock = worker.slice(worker.indexOf("const schemas = {"), worker.indexOf("};", worker.indexOf("const schemas = {")));
const doBlock = worker.slice(worker.indexOf("const allowedKeys = {"), worker.indexOf("};", worker.indexOf("const allowedKeys = {")));
const agentCases = [...agent.slice(agent.indexOf("async function handleAction")).matchAll(/case "([a-z_]+)":/g)].map(m => m[1]);

check("Worker advertises tools", listed.length >= 20, listed.length);
check("no duplicate tool names", new Set(listed).size === listed.length, listed.join(","));
check("tools/list == MCP-layer allowed keys", sameSet(listed, keysOf(mcpBlock)), diff(listed, keysOf(mcpBlock)));
check("tools/list == Durable Object allowed keys", sameSet(listed, keysOf(doBlock)), diff(listed, keysOf(doBlock)));
check("tools/list == agent actions", sameSet(listed, agentCases), diff(listed, agentCases));

// Every tool has annotations (read-only / destructive hints).
const defs = worker.slice(listStart, listEnd).split(/^\s{8}\{\n\s{10}name: /m).slice(1);
check("every tool has annotations", defs.length === listed.length && defs.every(d => d.includes("annotations:")), `${defs.length} defs`);

// Tools that change things must not be marked read-only.
const mustWrite = ["file_write", "file_str_replace", "file_multi_edit", "file_delete", "exec", "job_start", "job_kill",
  "terminal_create", "terminal_write", "terminal_kill", "web_fetch"];
for (const name of mustWrite) {
  const def = defs.find(d => d.startsWith(`"${name}"`)) || "";
  check(`${name} is not marked read-only`, def.includes("...WRITE") || def.includes("...RUN") || def.includes("readOnlyHint: false"), def.slice(0, 60));
}
const mustRead = ["status", "echo", "file_read", "file_list", "file_grep", "file_glob", "job_poll", "job_log", "job_list",
  "terminal_read", "terminal_status", "terminal_list"];
for (const name of mustRead) {
  const def = defs.find(d => d.startsWith(`"${name}"`)) || "";
  check(`${name} is marked read-only`, def.includes("...READ"), def.slice(0, 60));
}

// Scope table: every tool has a scope, and scopeCheck enforces it.
{
  const start = worker.indexOf("const SCOPE_READ");
  const end = worker.indexOf("function scopeCheck");
  const endFn = worker.indexOf("\n}\n", end) + 3;
  const code = worker.slice(start, endFn) + "\nmodule.exports = { TOOL_SCOPE, scopeCheck };";
  const m = { exports: {} };
  new Function("module", code)(m);
  const { TOOL_SCOPE, scopeCheck } = m.exports;
  const missing = listed.filter(n => !TOOL_SCOPE[n]);
  check("every advertised tool has a scope", missing.length === 0, missing.join(","));
  check("scope table has no tools the Worker does not advertise", Object.keys(TOOL_SCOPE).every(n => listed.includes(n)), Object.keys(TOOL_SCOPE).filter(n => !listed.includes(n)).join(","));
  const readOnly = { scopes: ["mcp:read"] };
  const withAll = { scopes: ["mcp:read", "mcp:write", "mcp:exec", "mcp:network"] };
  check("read-only token: read tools allowed", scopeCheck("file_read", { scope: ["mcp:read"] }) === null);
  check("read-only token: write refused", scopeCheck("file_write", { scope: ["mcp:read"] }) === "mcp:write", scopeCheck("file_write", { scope: ["mcp:read"] }));
  check("read-only token: exec refused", scopeCheck("exec", { scope: ["mcp:read"] }) === "mcp:exec");
  check("read-only token: web_fetch refused", scopeCheck("web_fetch", { scope: ["mcp:read"] }) === "mcp:network");
  check("token with all scopes: everything allowed", listed.every(n => scopeCheck(n, { scope: Object.values({ r: "mcp:read", w: "mcp:write", e: "mcp:exec", n: "mcp:network" }) }) === null));
  check("missing auth fails closed", scopeCheck("file_read", undefined) === "mcp:read");
  check("unknown tool refused", scopeCheck("rm_everything", { scope: ["mcp:read", "mcp:write", "mcp:exec", "mcp:network"] }) === "unknown_tool");
}

// /cancel must live inside the Durable Object, never in the public Worker handler.
{
  const bridge = worker.indexOf("export class Bridge");
  const cancelAt = worker.indexOf('url.pathname === "/cancel"');
  check("/cancel route is inside the Durable Object class", cancelAt > bridge && bridge > 0, `bridge=${bridge} cancel=${cancelAt}`);
}

process.exit(failed ? 1 : 0);
