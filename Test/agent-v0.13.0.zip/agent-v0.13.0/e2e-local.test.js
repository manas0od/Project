"use strict";
// End-to-end test. Requires a LOCAL Worker running on :8789 with .dev.vars:
//   BRIDGE_TOKEN=local-test-token-0123456789abcdef
//   CFB_SESSION_SECRET=<32+ chars>   CFB_LOGIN_PASSWORD=<any>
// Start it with: npx wrangler dev --local --port 8789
// This never contacts the production Worker or your real phone.
// Set MOCK_PROOT=/path/to/proot-distro-double to exercise the ubuntu route.

const { spawn } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const BASE = "http://localhost:8789";
const TOK = "local-test-token-0123456789abcdef";
const H = fs.mkdtempSync(path.join(os.tmpdir(), "cfb-e2e-"));
const ROOT = path.join(H, "cfb-work");
fs.mkdirSync(path.join(H, ".cfb"));
fs.writeFileSync(path.join(H, ".cfb", "bridge.token"), TOK + "\n", { mode: 0o600 });

const answers = [];      // queued decisions, consumed in order by approval prompts
const promptsSeen = [];  // every prompt the phone would have shown
let buf = "";

const agent = spawn("node", [path.join(__dirname, "agent.js")], {
  env: {
    ...process.env,
    HOME: H,
    CFB_WS_URL: "ws://localhost:8789/connect",
    CFB_PROJECT_ROOT: ROOT,
    CFB_UBUNTU_PROJECT: ROOT,
    CFB_PROOT_DISTRO: process.env.MOCK_PROOT || "proot-distro",
    MOCK_LOG: path.join(H, "mock.log"),
  },
  stdio: ["pipe", "pipe", "pipe"],
});

agent.stdout.on("data", d => {
  buf += d.toString();
  for (;;) {
    const m = buf.match(/\[CFB APPROVAL\] ([\s\S]*?) \[y\/N(?:\/a)?\]/);
    if (!m) break;
    promptsSeen.push(m[1]);
    buf = buf.slice(m.index + m[0].length);
    agent.stdin.write((answers.shift() || "n") + "\n");
  }
});
agent.stderr.on("data", d => process.stderr.write("[agent] " + d));

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function call(action, payload) {
  const r = await fetch(BASE + "/request", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + TOK },
    body: JSON.stringify({
      type: "request",
      request_id: "rq" + Math.random().toString(36).slice(2, 12),
      action,
      payload,
    }),
  });
  const text = await r.text();
  let body;
  try { body = JSON.parse(text); } catch { body = { raw: text }; }
  return { status: r.status, body, result: body.result || {} };
}

let pass = 0, fail = 0;
function check(name, ok, info) {
  if (ok) pass++; else fail++;
  console.log((ok ? "PASS " : "FAIL ") + name + (ok ? "" : " -> " + JSON.stringify(info).slice(0, 300)));
}

(async () => {
  await sleep(2500); // agent connects

  let r = await call("status", {});
  check("status reaches agent through Worker", r.status === 200 && r.result.ok === true && r.result.project_root === ROOT, r);

  promptsSeen.length = 0;
  r = await call("file_list", { path: "." });
  check("file_list: no approval", r.result.ok === true && promptsSeen.length === 0, { r, promptsSeen });

  answers.push("n");
  r = await call("file_write", { path: "hello.txt", content: "hi\n" });
  check("file_write denied on phone -> denied_by_user", r.result.error === "denied_by_user", r);
  check("denied write left no file", !fs.existsSync(path.join(ROOT, "hello.txt")));

  answers.push("y");
  r = await call("file_write", { path: "hello.txt", content: "hi\n" });
  check("file_write approved -> file on disk", r.result.ok === true && fs.readFileSync(path.join(ROOT, "hello.txt"), "utf8") === "hi\n", r);

  r = await call("file_read", { path: "hello.txt" });
  check("file_read returns content", r.result.content === "hi\n", r);

  answers.push("y");
  r = await call("file_str_replace", { path: "hello.txt", old_str: "hi", new_str: "hello" });
  check("file_str_replace approved", r.result.ok === true && fs.readFileSync(path.join(ROOT, "hello.txt"), "utf8") === "hello\n", r);

  promptsSeen.length = 0;
  r = await call("exec", { command: "ls" });
  check("exec ls: exit 0, no approval", r.result.exit_code === 0 && promptsSeen.length === 0, { r, promptsSeen });

  answers.push("y");
  r = await call("exec", { command: "echo from-phone" });
  check("exec echo approved -> output returned", /from-phone/.test(r.result.output || ""), r);

  if (process.env.MOCK_PROOT) {
    answers.push("y");
    r = await call("exec", { command: "echo in-ubuntu", env: "ubuntu" });
    check("exec env=ubuntu goes through proot-distro", /in-ubuntu/.test(r.result.output || "") && fs.existsSync(path.join(H, "mock.log")), r);
  } else {
    console.log("SKIP ubuntu route (set MOCK_PROOT to test it)");
  }

  r = await call("file_write", { path: "../escape.txt", content: "a" });
  check("escape path refused by agent, exact code", r.result.error === "outside_project", r);

  r = await call("exec", { command: "ls", env: "windows" });
  check("invalid env refused by Worker, exact code", r.status === 400 && r.body.error === "invalid_exec", r);

  r = await call("rm_everything", {});
  check("unknown action refused by Worker", r.status === 400 && r.body.error === "unsupported_action", r);

  // ---- search, multi-edit, jobs and web fetch through the Worker ----
  answers.push("y");
  await call("file_write", { path: "src/app.py", content: "def alpha():\n    return 1\n\ndef beta():\n    return 2\n" });

  promptsSeen.length = 0;
  r = await call("file_grep", { pattern: "def (alpha|beta)" });
  check("file_grep through Worker: 2 matches, no approval", r.result.count === 2 && promptsSeen.length === 0, { r, promptsSeen });

  r = await call("file_glob", { pattern: "**/*.py" });
  check("file_glob through Worker", r.result.files?.includes("src/app.py"), r);

  answers.push("y");
  r = await call("file_multi_edit", { path: "src/app.py", edits: [
    { old_str: "return 1", new_str: "return 10" }, { old_str: "return 2", new_str: "return 20" }] });
  check("file_multi_edit approved: both edits applied",
    r.result.edits_applied === 2 && fs.readFileSync(path.join(ROOT, "src/app.py"), "utf8").includes("return 20"), r);
  check("multi-edit prompt showed the actual changes",
    promptsSeen.some(p => p.startsWith("MULTI-EDIT") && p.includes("- return 1") && p.includes("+ return 10")), promptsSeen);

  answers.push("a");
  r = await call("file_write", { path: "auto1.txt", content: "1" });
  const before = promptsSeen.length;
  r = await call("file_write", { path: "auto2.txt", content: "2" });
  check("answer 'a' once -> next edit needs no prompt", r.result.ok === true && promptsSeen.length === before, { r, before, now: promptsSeen.length });

  r = await call("web_fetch", { url: "http://127.0.0.1:9/" });
  check("web_fetch to a private address is refused with no prompt", r.result.error === "blocked_private_address", r);

  answers.push("y");
  r = await call("job_start", { command: "sleep 1; echo e2e-job; exit 2" });
  check("job_start approved through Worker", /^[a-f0-9]{12}$/.test(r.result.job_id || ""), r);
  const jobId = r.result.job_id;
  let p = await call("job_poll", { job_id: jobId });
  check("job_poll: running right after start", p.result.status === "running", p);
  await sleep(2200);
  p = await call("job_poll", { job_id: jobId });
  check("job_poll: exited with the real exit code", p.result.status === "exited" && p.result.exit_code === 2, p);
  r = await call("job_log", { job_id: jobId });
  check("job_log returns output", r.result.content === "e2e-job\n", r);
  r = await call("job_list", {});
  check("job_list includes it", r.result.jobs?.some(j => j.job_id === jobId), r);

  // The Worker rejects malformed requests before they reach the phone.
  promptsSeen.length = 0;
  for (const [action, payload, err] of [
    ["file_grep", { pattern: "" }, "invalid_file_grep"],
    ["file_glob", { pattern: "*", max_results: 9999 }, "invalid_file_glob"],
    ["web_fetch", { url: "http://x", max_chars: 999999 }, "invalid_web_fetch"],
    ["job_poll", { job_id: "../etc" }, "invalid_job_id"],
    ["job_log", { job_id: "aaaaaaaaaaaa", limit: 99999 }, "invalid_job_log"],
    ["file_multi_edit", { path: "a", edits: Array.from({ length: 21 }, () => ({ old_str: "a", new_str: "b" })) }, "invalid_file_multi_edit"],
    ["file_multi_edit", { path: "a", edits: [{ old_str: "a", new_str: "b", extra: 1 }] }, "invalid_file_multi_edit"],
  ]) {
    r = await call(action, payload);
    check(`Worker rejects bad ${action}`, r.status === 400 && r.body.error === err, r);
  }
  check("rejected requests never reached the phone", promptsSeen.length === 0, promptsSeen);

  console.log("\nApproval prompts the phone would have shown:");
  promptsSeen.forEach(p => console.log("  - " + p));
  console.log(`\n${pass} passed, ${fail} failed`);

  agent.kill();
  fs.rmSync(H, { recursive: true, force: true });
  process.exit(fail ? 1 : 0);
})().catch(e => {
  console.error("DRIVER ERROR", e);
  agent.kill();
  process.exit(2);
});
