"use strict";

const WebSocket = require("ws");
const fs = require("fs");
const net = require("net");
const path = require("path");
const os = require("os");
const readline = require("readline");
const { AsyncLocalStorage } = require("async_hooks");
const crypto = require("crypto");
const { spawn, spawnSync } = require("child_process");
const {
  resolveInside, classifyCommand, ApprovalQueue, PolicyError,
  sanitizeForTerminal, makeDiffPreview, previewContent, sessionCategoryFor,
  parsePolicy, policyAllows,
} = require("./gate");
const { createExtras } = require("./extras");

// ---------- Configuration ----------

// CFB_WS_URL exists only so tests can point at a local Worker. Production
// uses the default.
const BASE_URL = process.env.CFB_WS_URL ||
  "wss://claude-freedom-bridge.manasodvaigaod.workers.dev/connect";

const CFB_DIR = path.join(process.env.HOME, ".cfb");
const TOKEN_FILE = path.join(CFB_DIR, "bridge.token");
const SESSIONS_DIR = path.join(CFB_DIR, "sessions");
let PROJECT_ROOT = process.env.CFB_PROJECT_ROOT
  || path.join(process.env.HOME, "cfb-work");
const JOBS_DIR = path.join(CFB_DIR, "jobs");
const AUDIT_FILE = path.join(CFB_DIR, "audit.log");
const POLICY_FILE = path.join(CFB_DIR, "policy.json");
const APPROVAL_DIR = path.join(CFB_DIR, "approvals");
const NOTIFY_CMD = process.env.CFB_NOTIFY_CMD || "termux-notification";
const NOTIFY_REMOVE_CMD = process.env.CFB_NOTIFY_REMOVE_CMD || "termux-notification-remove";
// Termux has no /bin/sh; use its own shell when PREFIX is set.
const SH = process.env.PREFIX ? path.join(process.env.PREFIX, "bin", "sh") : "/bin/sh";
const PYTHON = process.env.PYTHON || "python";
const PROOT_DISTRO = process.env.CFB_PROOT_DISTRO || "proot-distro";
// Project directory as seen from inside the Ubuntu rootfs.
const UBUNTU_PROJECT = process.env.CFB_UBUNTU_PROJECT || "/root/cfb-work";
const EXEC_OUTPUT_CAP = 15000; // worst case JSON escaping (6x) stays under the Worker frame limit
const SESSIONS_PY = path.join(process.env.HOME, "cfb", "sessions.py");
const RUNNER_PY = path.join(process.env.HOME, "cfb", "runner.py");

const MAX_READ_BYTES = 15000;    // worst-case escaping stays under the Worker frame limit
const MAX_WRITE_BYTES = 16000; // matches the Worker: larger writes are refused at both layers
// One request must finish inside the Worker's 130 s window, including the time
// spent waiting for approval, so exec gets whatever budget is left.
const EXEC_BUDGET_MS = Number(process.env.CFB_EXEC_BUDGET_MS) || 120000;
const APPROVAL_TIMEOUT_MS = Number(process.env.CFB_APPROVAL_TIMEOUT_MS) || 120000;

// ---------- Startup checks ----------

if (!fs.existsSync(TOKEN_FILE)) {
  console.error("CFB token file not found.");
  process.exit(1);
}

// The token must not be readable by other users on the device.
const tokenMode = fs.statSync(TOKEN_FILE).mode & 0o777;
if ((tokenMode & 0o077) !== 0) {
  console.error(
    "Refusing to start: bridge.token is readable by group/others. Run: chmod 600 " + TOKEN_FILE
  );
  process.exit(1);
}

const TOKEN = fs.readFileSync(TOKEN_FILE, "utf8").trim();

if (!TOKEN) {
  console.error("CFB token file is empty.");
  process.exit(1);
}

fs.mkdirSync(PROJECT_ROOT, { recursive: true, mode: 0o700 });

// Optional trusted-workspace policy. Invalid file = refuse to start, so a typo
// can never silently widen or narrow what runs without asking.
let POLICY;
try {
  const raw = fs.existsSync(POLICY_FILE) ? fs.readFileSync(POLICY_FILE, "utf8") : undefined;
  POLICY = parsePolicy(raw);
} catch (error) {
  console.error("Refusing to start: ~/.cfb/policy.json is invalid (" + error.message + ").");
  process.exit(1);
}
// All relative-path and containment logic compares against the real path.
// On Android /data/data is a symlink to /data/user/0, so the unresolved path
// would make every relative path look like "../../..".
PROJECT_ROOT = fs.realpathSync(PROJECT_ROOT);
const EXEC_HOME = process.env.CFB_EXEC_HOME || PROJECT_ROOT;

// ---------- State ----------

let ws = null;
let reconnectTimer = null;
let heartbeatTimer = null;
let stopped = false;
let reconnectDelay = 2000;
const startedAt = Date.now();
const HEARTBEAT_MS = 20000;
const PONG_TIMEOUT_MS = 60000;
let lastPongAt = 0;
let pingCounter = 0;

const approvals = new ApprovalQueue({ timeoutMs: APPROVAL_TIMEOUT_MS });
// Tracks the request that owns each action, so a Worker-sent cancel can stop it.
const requestScope = new AsyncLocalStorage();
const activePrompts = new Map();   // approval id -> { owner, release }
const runningChildren = new Map(); // request id -> Set of child processes
// Answers left over from a previous run must not approve a new request.
try { fs.rmSync(APPROVAL_DIR, { recursive: true, force: true }); } catch {}
let approvalSeq = 0;
const MAX_PROMPT_CHARS = 40000;

// Append-only record of every approval decision and every unprompted command.
const AUDIT_MAX_BYTES = 5 * 1024 * 1024;

function audit(kind, text, extra = {}) {
  try {
    try {
      if (fs.existsSync(AUDIT_FILE) && fs.statSync(AUDIT_FILE).size > AUDIT_MAX_BYTES) {
        fs.renameSync(AUDIT_FILE, AUDIT_FILE + ".1");
      }
    } catch {}
    fs.appendFileSync(
      AUDIT_FILE,
      JSON.stringify({ t: new Date().toISOString(), kind, text: String(text).slice(0, 500), ...extra }) + "\n",
      { mode: 0o600 }
    );
  } catch {
    // Auditing must never block work.
  }
}

// Interactive prompt on the Termux terminal. This is the approval channel
// the user controls directly; the Worker can only request, never approve.
const prompt = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  terminal: false,
});
const pendingPrompts = [];
prompt.on("line", line => {
  const next = pendingPrompts.shift();
  if (next) next(line.trim().toLowerCase());
});

// Production approver: asks on the terminal. Resolves true (yes), "always"
// (yes, and remember for this session, only when offered) or false.
// Tests may replace it via setApprover(); nothing else changes the decision.
let approver = function askUser(question, allowAlways) {
  return new Promise(resolve => {
    console.log("\n[CFB APPROVAL] " + question + (allowAlways ? " [y/N/a]" : " [y/N]"));
    pendingPrompts.push(answer => {
      if (answer === "y" || answer === "yes") resolve(true);
      else if (allowAlways && (answer === "a" || answer === "always")) resolve("always");
      else resolve(false);
    });
  });
};
function setApprover(fn) { approver = fn; }

const sessionAllow = new Map(); // category -> label, cleared when the agent restarts
let approvalChain = Promise.resolve();

// Prompts are serialized: one question on screen at a time, answered in order,
// so a typed answer can never be applied to a different request.
function requireApproval(description, opts = {}) {
  const run = approvalChain.then(() => decideApproval(description, opts));
  approvalChain = run.catch(() => {});
  return run;
}

// Approval answers can also arrive from a notification button. The button runs
// a shell command that writes "y", "n" or "a" to a file named for this request.
function notifyEnabled() {
  if (process.env.CFB_NOTIFY === "0") return false;
  if (process.env.CFB_NOTIFY === "1") return true;
  const r = spawnSync(SH, ["-c", `command -v "${NOTIFY_CMD.replace(/"/g, "")}"`], { encoding: "utf8" });
  return r.status === 0 && r.stdout.trim().length > 0;
}

function safeNotifyPath(file) {
  // The path is placed inside a quoted shell command, so refuse anything that could break out.
  if (/['"`$\\\n]/.test(file)) throw new Error("unsafe_approval_dir");
  return file;
}

function waitForNotificationAnswer(id, allowAlways, timeoutMs) {
  const file = path.join(APPROVAL_DIR, id + ".answer");
  return new Promise(resolve => {
    const started = Date.now();
    const poll = setInterval(() => {
      if (Date.now() - started > timeoutMs) { clearInterval(poll); return resolve(null); }
      if (!fs.existsSync(file)) return;
      clearInterval(poll);
      let value = "";
      try { value = fs.readFileSync(file, "utf8").trim(); fs.unlinkSync(file); } catch {}
      if (value === "y") return resolve(true);
      if (value === "a" && allowAlways) return resolve("always");
      resolve(false);
    }, 400);
  });
}

function showNotification(id, shown, allowAlways) {
  fs.mkdirSync(APPROVAL_DIR, { recursive: true, mode: 0o700 });
  const dir = safeNotifyPath(APPROVAL_DIR);
  const answer = (v) => `sh -c 'printf ${v} > "${dir}/${id}.answer"'`;
  const first = shown.split("\n")[0];
  const content = first.length > 180 ? first.slice(0, 180) + "…" : first;
  const args = [
    "--id", "cfb-" + id,
    "--title", "CFB approval",
    "--content", content,
    "--button1", "Allow", "--button1-action", answer("y"),
    "--button2", "Deny", "--button2-action", answer("n"),
  ];
  if (allowAlways) args.push("--button3", "Always", "--button3-action", answer("a"));
  const r = spawnSync(NOTIFY_CMD, args, { encoding: "utf8", timeout: 5000 });
  return r.status === 0;
}

function removeNotification(id) {
  try { spawnSync(NOTIFY_REMOVE_CMD, ["cfb-" + id], { timeout: 3000 }); } catch {}
}

async function decideApproval(description, opts) {
  const shown = sanitizeForTerminal(description);
  if (shown.length > MAX_PROMPT_CHARS) {
    audit("denied", "prompt_too_large");
    return false;
  }

  // Trusted-workspace policy: only for requests that are not hard-blocked.
  // Every automatic approval is still written to the audit log.
  if (opts.policyReq) {
    const verdict = policyAllows(POLICY, opts.policyReq);
    if (verdict.auto) {
      audit("policy-auto", shown, { why: verdict.why });
      return true;
    }
  }

  const category = opts.category || null;
  if (category && sessionAllow.has(category)) {
    console.log("[auto-approved: " + sessionAllow.get(category) + "] " + shown.split("\n")[0]);
    audit("auto-approved", shown, { category });
    return true;
  }

  approvalSeq += 1;
  const id = `ap${approvalSeq}`;
  approvals.create(id, shown);

  const question = category
    ? `${shown}\n(a = always allow ${opts.label || category} for this session)`
    : shown;

  // A notification can only show one short line. Approve from it only when the
  // whole request fits on that line; longer or multi-line requests are answered
  // in Termux, where the complete text is shown.
  const owner = requestScope.getStore()?.requestId || null;
  let wasCancelled = false;
  let releaseCancel;
  const cancelled = new Promise(res => { releaseCancel = () => { wasCancelled = true; res(false); }; });
  activePrompts.set(id, { owner, release: releaseCancel });

  const fitsNotification = !shown.includes("\n") && shown.length <= 180;
  const notified = fitsNotification && notifyEnabled() && showNotification(id, shown, Boolean(category));
  let timer;
  const timeout = new Promise(resolve => {
    timer = setTimeout(() => {
      console.log("Approval timed out; denied.");
      pendingPrompts.length = 0; // drop the unanswered prompt so it cannot eat the next answer
      resolve(false);
    }, APPROVAL_TIMEOUT_MS);
  });

  let answer, source = "terminal";
  const terminal = approver(question, Boolean(category));
  if (notified) {
    const tapped = waitForNotificationAnswer(id, Boolean(category), APPROVAL_TIMEOUT_MS);
    answer = await Promise.race([
      terminal,
      tapped.then(v => { if (v !== null) source = "notification"; return v === null ? new Promise(() => {}) : v; }),
      timeout,
      cancelled,
    ]);
    if (source === "notification") pendingPrompts.length = 0;
    removeNotification(id);
  } else {
    answer = await Promise.race([terminal, timeout, cancelled]);
  }
  clearTimeout(timer);
  activePrompts.delete(id);
  // A cancelled prompt leaves its terminal resolver queued; drop it so it cannot
  // consume the next typed answer. Prompts are serialized, so it is the only one.
  if (wasCancelled) pendingPrompts.length = 0;

  if (answer === "always" && category) sessionAllow.set(category, opts.label || category);
  const approved = answer === true || answer === "always";
  approvals.decide(id, approved ? "approve" : "deny");
  audit(approved ? "approved" : "denied", shown, { ...(category ? { category } : {}), source });
  return approvals.get(id).state === "approved";
}

// Writes via a temp file and rename. Keeps the original file mode, so an
// executable script stays executable after an edit.
function atomicWrite(target, content) {
  let mode = 0o600;
  try { mode = fs.statSync(target).mode & 0o777; } catch {}
  const tmp = target + ".cfb-tmp-" + crypto.randomBytes(4).toString("hex");
  fs.writeFileSync(tmp, content, { mode });
  fs.renameSync(tmp, target);
}

// ---------- File tools ----------

function fileError(error) {
  if (error instanceof PolicyError) return { ok: false, error: error.code };
  if (error.code === "ENOENT") return { ok: false, error: "not_found" };
  if (error.code === "EISDIR") return { ok: false, error: "is_directory" };
  if (error.code === "ENOTDIR") return { ok: false, error: "not_directory" };
  return { ok: false, error: "file_error" };
}

function readFileTool(payload) {
  try {
    const target = resolveInside(PROJECT_ROOT, payload.path);
    const stat = fs.statSync(target);
    if (stat.isDirectory()) return { ok: false, error: "is_directory" };

    const offset = Number.isInteger(payload.offset) && payload.offset >= 0 ? payload.offset : 0;
    const limit = Math.min(
      Number.isInteger(payload.limit) && payload.limit > 0 ? payload.limit : MAX_READ_BYTES,
      MAX_READ_BYTES
    );

    const fd = fs.openSync(target, "r");
    const buf = Buffer.alloc(limit);
    const n = fs.readSync(fd, buf, 0, limit, offset);
    fs.closeSync(fd);

    return {
      ok: true,
      content: buf.slice(0, n).toString("utf8"),
      offset,
      bytes_returned: n,
      size: stat.size,
      eof: offset + n >= stat.size,
    };
  } catch (error) {
    return fileError(error);
  }
}

function listDirTool(payload) {
  try {
    const target = resolveInside(PROJECT_ROOT, payload.path || ".");
    const entries = fs.readdirSync(target, { withFileTypes: true })
      .slice(0, 500)
      .map(e => ({
        name: e.name,
        type: e.isSymbolicLink() ? "symlink" : e.isDirectory() ? "dir" : e.isFile() ? "file" : "other",
      }));
    return { ok: true, entries };
  } catch (error) {
    return fileError(error);
  }
}

async function writeFileTool(payload) {
  if (typeof payload.content !== "string") return { ok: false, error: "content_required" };
  if (Buffer.byteLength(payload.content) > MAX_WRITE_BYTES) return { ok: false, error: "content_too_large" };

  try {
    const target = resolveInside(PROJECT_ROOT, payload.path);
    const exists = fs.existsSync(target);
    const rel = path.relative(PROJECT_ROOT, target);
    const bytes = Buffer.byteLength(payload.content);
    const head = exists
      ? `OVERWRITE ${rel} (${fs.statSync(target).size} -> ${bytes} bytes)`
      : `CREATE ${rel} (${bytes} bytes)`;

    const approved = await requireApproval(
      `${head}\n${previewContent(payload.content)}`,
      { category: "edit", label: "file edits inside the project", policyReq: { kind: "edit" } }
    );
    if (!approved) return { ok: false, error: "denied_by_user" };

    fs.mkdirSync(path.dirname(target), { recursive: true, mode: 0o700 });
    atomicWrite(target, payload.content);
    return { ok: true, path: rel, bytes };
  } catch (error) {
    return fileError(error);
  }
}

async function strReplaceTool(payload) {
  if (typeof payload.old_str !== "string" || payload.old_str.length === 0) return { ok: false, error: "old_str_required" };
  if (typeof payload.new_str !== "string") return { ok: false, error: "new_str_required" };

  try {
    const target = resolveInside(PROJECT_ROOT, payload.path);
    const current = fs.readFileSync(target, "utf8");
    const count = current.split(payload.old_str).length - 1;

    if (count === 0) return { ok: false, error: "old_str_not_found" };
    if (count > 1) return { ok: false, error: "old_str_not_unique", occurrences: count };

    const approved = await requireApproval(
      `EDIT ${path.relative(PROJECT_ROOT, target)}\n${makeDiffPreview(payload.old_str, payload.new_str)}`,
      { category: "edit", label: "file edits inside the project", policyReq: { kind: "edit" } }
    );
    if (!approved) return { ok: false, error: "denied_by_user" };

    // Re-read after approval: the file may have changed while waiting.
    const fresh = fs.readFileSync(target, "utf8");
    if (fresh.split(payload.old_str).length - 1 !== 1) return { ok: false, error: "file_changed_during_approval" };

    atomicWrite(target, fresh.replace(payload.old_str, () => payload.new_str));
    return { ok: true, path: path.relative(PROJECT_ROOT, target) };
  } catch (error) {
    return fileError(error);
  }
}

async function deleteFileTool(payload) {
  try {
    const target = resolveInside(PROJECT_ROOT, payload.path);
    if (target === PROJECT_ROOT) return { ok: false, error: "cannot_delete_root" };
    if (!fs.existsSync(target)) return { ok: false, error: "not_found" };
    const stat = fs.statSync(target);
    if (stat.isDirectory()) return { ok: false, error: "is_directory_use_exec" };

    // Deletes never offer "always": each one is confirmed individually.
    const approved = await requireApproval(
      `DELETE ${path.relative(PROJECT_ROOT, target)} (${stat.size} bytes)`
    );
    if (!approved) return { ok: false, error: "denied_by_user" };

    fs.unlinkSync(target);
    return { ok: true, path: path.relative(PROJECT_ROOT, target) };
  } catch (error) {
    return fileError(error);
  }
}

// ---------- Exec with exit codes ----------

const PASSTHROUGH_ENV = [
  "PATH", "PREFIX", "LD_PRELOAD", "LD_LIBRARY_PATH", "TMPDIR",
  "ANDROID_ROOT", "ANDROID_DATA", "LANG", "LC_ALL",
];

// Environment for commands. Termux needs PREFIX and LD_PRELOAD (termux-exec)
// or scripts with a "#!/usr/bin/env" line will not start. HOME is confined to
// the project unless CFB_EXEC_HOME says otherwise, so ~/.ssh, ~/.git-credentials
// and the bridge token are not reachable through it.
function execBaseEnv() {
  const env = {};
  for (const key of PASSTHROUGH_ENV) {
    if (process.env[key] !== undefined) env[key] = process.env[key];
  }
  env.HOME = EXEC_HOME;
  env.TERM = "dumb";
  if (!env.LANG) env.LANG = "C.UTF-8";
  return env;
}

// Single place that decides how a command is launched, shared by exec and jobs.
function buildSpawnSpec(envName, cwdAbs, command) {
  if (envName === "ubuntu") {
    return ubuntuSpawnSpec(path.relative(PROJECT_ROOT, cwdAbs), command);
  }
  return { file: SH, args: ["-c", command], cwd: cwdAbs, env: execBaseEnv() };
}

async function execTool(payload, t0) {
  if (typeof payload.command !== "string") return { ok: false, error: "command_required" };

  const env = payload.env || "termux";
  if (env !== "termux" && env !== "ubuntu") return { ok: false, error: "invalid_env" };

  let decision;
  try {
    decision = classifyCommand(payload.command);
  } catch (error) {
    return fileError(error);
  }

  let cwd;
  try {
    cwd = resolveInside(PROJECT_ROOT, payload.cwd || ".");
  } catch (error) {
    return fileError(error);
  }

  if (env === "ubuntu" && !prootAvailable()) {
    return { ok: false, error: "proot_distro_not_installed" };
  }

  if (decision.level === "ask") {
    const network = /\b(curl|wget|nc|ssh|scp)\b/.test(payload.command) ? "  [NETWORK]" : "";
    const where = env === "ubuntu" ? "[ubuntu]" : "[termux]";
    const sess = sessionCategoryFor(payload.command, env);
    const approved = await requireApproval(
      `RUN ${where} in ${path.relative(PROJECT_ROOT, cwd) || "."}: ${payload.command}  [${decision.reason}]${network}`,
      { ...(sess ? { category: sess.category, label: sess.label } : {}), policyReq: { kind: "exec", command: payload.command } }
    );
    if (!approved) return { ok: false, error: "denied_by_user" };
  } else {
    audit("exec-allowed", payload.command);
  }

  const spec = buildSpawnSpec(env, cwd, payload.command);
  const timeoutMs = Math.max(
    Math.min(5000, EXEC_BUDGET_MS),
    EXEC_BUDGET_MS - (Date.now() - t0)
  );

  return new Promise(resolve => {
    const child = spawn(spec.file, spec.args, {
      cwd: spec.cwd,
      env: spec.env,
      stdio: ["ignore", "pipe", "pipe"],
      detached: true,
    });

    const owner = requestScope.getStore()?.requestId || null;
    if (owner) {
      if (!runningChildren.has(owner)) runningChildren.set(owner, new Set());
      runningChildren.get(owner).add(child);
    }
    const forget = () => {
      if (owner && runningChildren.has(owner)) {
        runningChildren.get(owner).delete(child);
        if (runningChildren.get(owner).size === 0) runningChildren.delete(owner);
      }
    };

    let out = "";
    let truncated = false;
    let timedOut = false;
    const collect = chunk => {
      if (out.length >= EXEC_OUTPUT_CAP) { truncated = true; return; }
      out += chunk.toString();
      if (out.length > EXEC_OUTPUT_CAP) { out = out.slice(0, EXEC_OUTPUT_CAP); truncated = true; }
    };
    child.stdout.on("data", collect);
    child.stderr.on("data", collect);

    const timer = setTimeout(() => {
      timedOut = true;
      try { process.kill(-child.pid, "SIGKILL"); } catch {}
    }, timeoutMs);

    child.on("close", (code, signal) => {
      clearTimeout(timer);
      forget();
      const result = {
        ok: true,
        env,
        exit_code: code,
        signal: signal || null,
        output: out,
        output_truncated: truncated,
        finished: !timedOut,
      };
      if (timedOut) {
        result.timed_out = true;
        result.hint = "Command was stopped at the time limit. Use job_start for long-running commands, then job_poll and job_log.";
      }
      resolve(result);
    });
    child.on("error", error => {
      clearTimeout(timer);
      forget();
      resolve({ ok: false, error: "spawn_failed", detail: error.message });
    });
  });
}

// Stops everything one MCP request is still doing: releases its approval
// prompts as denials and kills any command it started. Background jobs are not
// touched; they are designed to outlive the request.
function cancelRequest(requestId) {
  let stopped = 0;
  for (const entry of activePrompts.values()) {
    if (entry.owner === requestId) { entry.release(); stopped++; }
  }
  const children = runningChildren.get(requestId);
  if (children) {
    for (const child of children) {
      try { process.kill(-child.pid, "SIGKILL"); } catch {}
      stopped++;
    }
    runningChildren.delete(requestId);
  }
  audit("cancelled", "request " + requestId, { stopped });
  return stopped;
}

function prootAvailable() {
  // Run the program directly with fixed arguments. The configured name is never
  // placed inside a shell command. A non-zero exit still means the program exists.
  const r = spawnSync(PROOT_DISTRO, ["--version"], { encoding: "utf8", timeout: 5000 });
  return !(r.error && r.error.code === "ENOENT");
}

// Runs the command inside the Ubuntu rootfs. Directory and command are passed
// base64-encoded so no host-side quoting can alter what runs inside Ubuntu.
function ubuntuSpawnSpec(relCwd, command) {
  const b64 = str => Buffer.from(str, "utf8").toString("base64");
  const dir = UBUNTU_PROJECT + (relCwd && relCwd !== "." ? "/" + relCwd : "");
  const script =
    `cd -- "$(printf %s '${b64(dir)}' | base64 -d)" && ` +
    `printf %s '${b64(command)}' | base64 -d | /bin/sh`;
  return {
    file: PROOT_DISTRO,
    args: ["login", "ubuntu", "--", "/bin/sh", "-c", script],
    cwd: PROJECT_ROOT,
    // proot-distro needs Termux variables (PREFIX etc.) to find its rootfs.
    env: ubuntuHostEnv(),
  };
}

// Only what proot-distro needs to find its rootfs, plus locale and terminal.
// Everything else (exported API keys, credentials, tokens) stays out.
function ubuntuHostEnv() {
  const env = {};
  for (const key of ["PATH", "PREFIX", "LD_PRELOAD", "LD_LIBRARY_PATH", "TMPDIR", "ANDROID_ROOT", "ANDROID_DATA"]) {
    if (process.env[key] !== undefined) env[key] = process.env[key];
  }
  env.HOME = "/root"; // home inside the Ubuntu rootfs, never the Termux home
  env.LANG = "C.UTF-8";
  env.TERM = "dumb";
  return env;
}

const extras = createExtras({
  getProjectRoot: () => PROJECT_ROOT,
  JOBS_DIR, SH,
  requireApproval, buildSpawnSpec, prootAvailable, audit, fileError, atomicWrite,
  policyAllows, getPolicy: () => POLICY,
});

// ---------- Terminal session tools (unchanged protocol) ----------

function validSessionId(id) {
  return typeof id === "string" && /^[a-f0-9]{12}$/.test(id);
}

function socketRequest(sessionId, request) {
  if (!validSessionId(sessionId)) {
    return Promise.reject(new Error("Invalid session ID"));
  }

  const socketPath = path.join(SESSIONS_DIR, sessionId, "control.sock");

  return new Promise((resolve, reject) => {
    const socket = net.createConnection(socketPath);
    let response = "";
    let settled = false;

    const timer = setTimeout(() => {
      socket.destroy();
      finish(new Error("Terminal socket request timed out"));
    }, 7000);

    function finish(error, result) {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (error) reject(error);
      else resolve(result);
    }

    socket.on("connect", () => {
      socket.end(JSON.stringify(request) + "\n");
    });
    socket.on("data", chunk => {
      response += chunk.toString();
      if (response.length > 131072) {
        socket.destroy();
        finish(new Error("Terminal response too large"));
      }
    });
    socket.on("end", () => {
      try {
        const result = JSON.parse(response);
        if (!result.ok) throw new Error(result.error || "Terminal operation failed");
        finish(null, result);
      } catch (error) {
        finish(error);
      }
    });
    socket.on("error", error => {
      finish(new Error(`Terminal socket: ${error.message}`));
    });
  });
}

function createTerminal(payload) {
  const cwd = resolveInside(PROJECT_ROOT, payload.cwd || ".");
  const args = [SESSIONS_PY, "create", "--cwd", cwd];

  const result = spawnSync(PYTHON, args, {
    encoding: "utf8",
    timeout: 12000,
    maxBuffer: 16384,
  });

  if (result.error) throw new Error(result.error.message);
  if (result.status !== 0) {
    throw new Error((result.stderr || result.stdout || "Session creation failed").trim());
  }

  const match = result.stdout.match(/Session created:\s*([a-f0-9]{12})/);
  if (!match) throw new Error("Could not find the new session ID");

  return { ok: true, session_id: match[1], output: result.stdout.trim() };
}

function listTerminals() {
  if (!fs.existsSync(SESSIONS_DIR)) return { ok: true, sessions: [] };

  const sessions = [];
  for (const id of fs.readdirSync(SESSIONS_DIR)) {
    if (!validSessionId(id)) continue;
    try {
      const meta = JSON.parse(fs.readFileSync(path.join(SESSIONS_DIR, id, "meta.json"), "utf8"));
      sessions.push({
        session_id: id,
        status: meta.status || "unknown",
        cwd: meta.cwd || null,
        worker_pid: meta.worker_pid || null,
        shell_pid: meta.shell_pid || null,
        created_at: meta.created_at || null,
      });
    } catch {
      // Ignore incomplete or unreadable metadata.
    }
  }
  return { ok: true, sessions };
}

// ---------- Dispatch ----------

// Output from these tools is data written by others (files, commands, logs,
// terminals). Claude must treat it as content to read, never as instructions.
const UNTRUSTED_OUTPUT_ACTIONS = new Set([
  "file_read", "file_grep", "file_glob", "file_list", "exec",
  "job_poll", "job_log", "terminal_read", "web_fetch",
]);

async function handleAction(action, payload) {
  const result = await dispatchAction(action, payload);
  if (UNTRUSTED_OUTPUT_ACTIONS.has(action) && result && typeof result === "object") {
    result.untrusted_content = true;
  }
  return result;
}

async function dispatchAction(action, payload) {
  const t0 = Date.now();
  switch (action) {
    case "status":
      return {
        ok: true,
        status: "online",
        platform: process.platform,
        architecture: process.arch,
        os_release: os.release(),
        uptime_seconds: Math.floor((Date.now() - startedAt) / 1000),
        project_root: PROJECT_ROOT,
      };

    case "echo":
      return { ok: true, message: String(payload.message ?? "") };

    case "file_read":
      return readFileTool(payload);
    case "file_list":
      return listDirTool(payload);
    case "file_write":
      return writeFileTool(payload);
    case "file_str_replace":
      return strReplaceTool(payload);
    case "file_delete":
      return deleteFileTool(payload);

    case "exec":
      return execTool(payload, t0);

    case "file_multi_edit":
      return extras.multiEdit(payload);
    case "file_grep":
      return extras.grep(payload);
    case "file_glob":
      return extras.glob(payload);
    case "web_fetch":
      return extras.webFetch(payload, t0, EXEC_BUDGET_MS);
    case "job_start":
      return extras.jobStart(payload);
    case "job_poll":
      return extras.jobPoll(payload);
    case "job_log":
      return extras.jobLog(payload);
    case "job_list":
      return extras.jobList();
    case "job_kill":
      return extras.jobKill(payload);

    case "terminal_create": {
      const cwd = resolveInside(PROJECT_ROOT, payload.cwd || ".");
      const approved = await requireApproval(
        `START terminal session in ${path.relative(PROJECT_ROOT, cwd) || "."}`
      );
      if (!approved) return { ok: false, error: "denied_by_user" };
      return createTerminal(payload);
    }

    case "terminal_write": {
      const text = payload.text + (payload.press_enter === false ? "" : "\n");
      const shown = JSON.stringify(payload.text); // full text: the Worker caps input at 3000 characters
      const decision = classifyCommand(payload.text.trim() || "x");
      const approved = await requireApproval(
        `TYPE into session ${payload.session_id}: ${shown}` +
        (decision.level === "ask" ? `  [${decision.reason}]` : "")
      );
      if (!approved) return { ok: false, error: "denied_by_user" };
      return socketRequest(payload.session_id, { op: "write", text });
    }
    case "terminal_read":
      return socketRequest(payload.session_id, {
        op: "read",
        wait: payload.wait ?? 0.3,
        max_bytes: payload.max_bytes ?? MAX_READ_BYTES,
      });
    case "terminal_status":
      return socketRequest(payload.session_id, { op: "status" });
    case "terminal_list":
      return listTerminals();
    case "terminal_kill": {
      // Terminal kills are not destructive to files, but they still ask.
      const approved = await requireApproval(`KILL terminal session ${payload.session_id}`);
      if (!approved) return { ok: false, error: "denied_by_user" };
      return socketRequest(payload.session_id, { op: "kill" });
    }

    default:
      throw new Error("Unsupported action");
  }
}

// ---------- WebSocket connection ----------

function connect() {
  if (stopped) return;

  console.log("Connecting to CFB...");

  ws = new WebSocket(BASE_URL, {
    headers: { Authorization: `Bearer ${TOKEN}` },
    handshakeTimeout: 15000,
  });

  ws.on("open", () => {
    console.log("Connected to CFB.");
    reconnectDelay = 2000;
    lastPongAt = Date.now();
    clearInterval(heartbeatTimer);

    heartbeatTimer = setInterval(() => {
      if (!ws || ws.readyState !== WebSocket.OPEN) return;
      if (Date.now() - lastPongAt > PONG_TIMEOUT_MS) {
        console.error("No heartbeat reply; reconnecting.");
        ws.terminate();
        return;
      }
      pingCounter += 1;
      ws.send(JSON.stringify({ type: "ping", id: `a${pingCounter}` }));
    }, HEARTBEAT_MS);
  });

  ws.on("message", async raw => {
    let message;
    try {
      message = JSON.parse(raw.toString());
    } catch {
      console.error("Received invalid JSON.");
      return;
    }

    if (message.type === "connected") {
      console.log("Handshake successful. Protocol:", message.protocol);
      return;
    }
    if (message.type === "pong") {
      lastPongAt = Date.now();
      return;
    }
    if (message.type === "cancel" && typeof message.request_id === "string") {
      cancelRequest(message.request_id);
      return;
    }
    if (message.type !== "request") {
      console.log("Unknown message:", message.type);
      return;
    }

    const requestId = message.request_id;
    let result;
    try {
      result = await requestScope.run({ requestId }, () => handleAction(message.action, message.payload || {}));
    } catch (error) {
      result = { ok: false, error: String(error.message || error) };
    }

    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: "response", request_id: requestId, result }));
    }
  });

  ws.on("error", error => {
    console.error("WebSocket error:", error.message);
  });

  ws.on("close", (code, reason) => {
    console.log("Disconnected:", code, reason.toString());
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;

    if (!stopped) {
      console.log(`Reconnecting in ${reconnectDelay / 1000}s...`);
      reconnectTimer = setTimeout(connect, reconnectDelay);
      reconnectDelay = Math.min(reconnectDelay * 2, 30000);
    }
  });
}

function shutdown() {
  if (stopped) return;
  stopped = true;
  clearTimeout(reconnectTimer);
  clearInterval(heartbeatTimer);
  if (ws) ws.close();
  prompt.close();
  console.log("CFB agent stopped.");
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

module.exports = {
  handleAction, PROJECT_ROOT, setApprover, ubuntuSpawnSpec,
  setAddressPolicy: extras.setAddressPolicy,
  cancelRequest, requestScope,
};

if (require.main === module) connect();
