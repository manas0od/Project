// Tests for the Worker-side logic (src/exec-protocol.js) plus a full in-process
// "loopback" of Worker job store <-> agent executor, using the real agent code.
// Run:  node --test test/*.test.js

import { test, describe, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import {
  EXEC_LIMITS, EXEC_TOOLS, ExecJobs, execEnabled, handleTerminalTool, presentJob,
  sanitizeAgentJob, toolsFor, validateCancelArgs, validateExecuteArgs, validateStatusArgs
} from "../src/exec-protocol.js";
import { makeWorkspace, makeAgent, autoApprover, gatedApprover, silentApprover, waitUntil, newId } from "./helpers.js";

const cleanups = [];
afterEach(() => { while (cleanups.length) cleanups.pop()(); });

class MemStorage {
  constructor() { this.map = new Map(); }
  async get(k) { const v = this.map.get(k); return v === undefined ? undefined : structuredClone(v); }
  async put(k, v) { this.map.set(k, structuredClone(v)); }
  async delete(k) { this.map.delete(k); }
  async list({ prefix }) { return new Map([...this.map].filter(([k]) => k.startsWith(prefix)).map(([k, v]) => [k, structuredClone(v)])); }
}

// Worker-side ExecJobs wired to a real agent manager through a fake WebSocket.
function makeLoop({ approver = autoApprover(), now } = {}) {
  const ws = makeWorkspace();
  const storage = new MemStorage();
  const link = { connected: true, connectedAt: 0 };
  const loop = { ws, storage, link };

  const wire = agent => {
    link.deliver = m => queueMicrotask(() => {
      if (m.type === "exec_update") loop.jobs.onAgentUpdate(m.job);
      else if (m.type === "exec_sync") loop.jobs.onAgentSync(m.jobs, { connectedAt: link.connectedAt });
    });
    return agent;
  };
  loop.agent = wire(makeAgent(ws, { approver, link }));
  loop.jobs = new ExecJobs({
    storage,
    now,
    agentConnected: () => link.connected,
    sendToAgent: m => {
      if (!link.connected) return false;
      setImmediate(() => (m.type === "exec_request" ? loop.agent.manager.handleRequest(m) : loop.agent.manager.handleCancel(m)));
      return true;
    }
  });
  loop.restartAgent = () => {           // the Termux agent process was killed and restarted
    loop.agent.manager.shutdown();
    loop.agent = wire(makeAgent(ws, { approver, link }));
  };
  loop.reconnect = async () => {        // what agent.js does in its "open" handler
    link.connected = true;
    link.connectedAt = Date.now() + 1;
    await loop.jobs.onAgentSync(loop.agent.manager.snapshotAll(), { connectedAt: link.connectedAt });
  };
  cleanups.push(() => { loop.agent.manager.shutdown(); ws.cleanup(); });
  return loop;
}

const call = (loop, name, args) => handleTerminalTool(name, args, loop.jobs);
const body = r => r.structuredContent;

describe("TEST 1 MCP tool registration", () => {
  test("terminal tools exist only when explicitly enabled", () => {
    assert.deepEqual(toolsFor({}), []);
    assert.deepEqual(toolsFor({ CFB_EXEC_ENABLED: "0" }), []);
    assert.deepEqual(toolsFor({ CFB_EXEC_ENABLED: "true" }), []);
    assert.deepEqual(toolsFor(undefined), []);
    assert.equal(execEnabled({ CFB_EXEC_ENABLED: "1" }), true);
    assert.deepEqual(toolsFor({ CFB_EXEC_ENABLED: "1" }).map(t => t.name), ["terminal_execute", "terminal_status", "terminal_cancel"]);
  });

  test("schemas are strict, and there is deliberately NO approve tool", () => {
    for (const t of EXEC_TOOLS) {
      assert.equal(t.inputSchema.type, "object");
      assert.equal(t.inputSchema.additionalProperties, false);
    }
    assert.deepEqual(EXEC_TOOLS[0].inputSchema.required, ["command"]);
    const names = EXEC_TOOLS.map(t => t.name).join(" ");
    assert.doesNotMatch(names, /approve|reject|allow/, "Claude must not be able to approve its own commands");
  });

  test("the public Worker handler never routes /exec; the Durable Object checks the flag", () => {
    const src = fs.readFileSync(new URL("../src/index.js", import.meta.url), "utf8");
    const bridgeStart = src.indexOf("export class Bridge");
    assert.ok(bridgeStart > 0);
    const publicPart = src.slice(0, bridgeStart);
    assert.equal(/pathname === "\/exec"/.test(publicPart), false, "/exec must not be reachable from the public handler");
    assert.match(src.slice(bridgeStart), /pathname === "\/exec"[\s\S]{0,200}execEnabled\(this\.env\)/);
    assert.match(src, /EXEC_TOOL_NAMES\.has\(action\)[\s\S]{0,300}!execEnabled\(env\)/);
  });
});

describe("argument validation", () => {
  test("terminal_execute", () => {
    assert.equal(validateExecuteArgs({ command: "ls" }).value.timeout_seconds, 30);
    assert.equal(validateExecuteArgs({ command: "ls", timeout_seconds: 300 }).ok, true);
    for (const bad of [
      null, [], "ls", {}, { command: "" }, { command: "   " }, { command: 5 }, { command: "a".repeat(2001) },
      { command: "ls\nid" }, { command: "ls\u0000" }, { command: "ls", extra: 1 },
      { command: "ls", timeout_seconds: 0 }, { command: "ls", timeout_seconds: 301 }, { command: "ls", timeout_seconds: 1.5 }, { command: "ls", timeout_seconds: "5" },
      { command: "ls", working_directory: "" }, { command: "ls", working_directory: 5 }, { command: "ls", working_directory: "a\nb" }
    ]) assert.equal(validateExecuteArgs(bad).ok, false, JSON.stringify(bad));
  });

  test("terminal_status and terminal_cancel", () => {
    assert.equal(validateStatusArgs({}).ok, true);
    assert.equal(validateStatusArgs({ command_id: "a".repeat(32), wait_seconds: 25 }).ok, true);
    for (const bad of [{ command_id: "nope" }, { command_id: "A".repeat(32) }, { wait_seconds: 26 }, { wait_seconds: -1 }, { x: 1 }]) {
      assert.equal(validateStatusArgs(bad).ok, false, JSON.stringify(bad));
    }
    assert.equal(validateCancelArgs({ command_id: "a".repeat(32) }).ok, true);
    assert.equal(validateCancelArgs({}).ok, false);
  });
});

describe("TEST 2 command requests (job store) and agent availability", () => {
  test("nothing is queued when the agent is not connected", async () => {
    const loop = makeLoop();
    loop.link.connected = false;
    const r = await call(loop, "terminal_execute", { command: "echo hi" });
    assert.equal(r.isError, true);
    assert.match(r.content[0].text, /agent_unavailable/);
    assert.equal((await loop.jobs.list()).length, 0);
  });

  test("end to end: request, human approval, execution, result", async () => {
    const loop = makeLoop();
    const r = await call(loop, "terminal_execute", { command: "echo hello-from-termux" });
    assert.equal(r.isError, false);
    const id = body(r).command_id;
    const done = body(await call(loop, "terminal_status", { command_id: id, wait_seconds: 10 }));
    assert.equal(done.state, "completed");
    assert.equal(done.exit_code, 0);
    assert.equal(done.succeeded, true);
    assert.equal(done.stdout.trim(), "hello-from-termux");
    assert.equal(done.agent_connected, true);
  });

  test("a non-zero exit code is reported as a failure, never a success", async () => {
    const loop = makeLoop();
    loop.ws.write("fail.js", "process.exit(7)");
    const id = body(await call(loop, "terminal_execute", { command: "node fail.js" })).command_id;
    const done = body(await call(loop, "terminal_status", { command_id: id, wait_seconds: 10 }));
    assert.equal(done.state, "completed");
    assert.equal(done.exit_code, 7);
    assert.equal(done.succeeded, false);
    assert.match(done.next_step, /FAILED/);
  });

  test("a blocked command is reported immediately with reasons", async () => {
    const loop = makeLoop();
    const r = body(await call(loop, "terminal_execute", { command: "sudo rm -rf /" }));
    assert.equal(r.state, "blocked");
    assert.equal(r.terminal, true);
    assert.equal(r.succeeded, false);
    assert.ok(r.reasons.length > 0);
    assert.match(r.next_step, /BLOCKED/);
  });

  test("a pending command tells Claude it cannot approve it, and nothing runs yet", async () => {
    const gate = gatedApprover();
    const loop = makeLoop({ approver: gate });
    const r = body(await call(loop, "terminal_execute", { command: "touch pending.txt" }));
    assert.equal(r.state, "pending_approval");
    assert.match(r.next_step, /cannot approve/i);
    await new Promise(res => setTimeout(res, 200));
    assert.equal(loop.ws.exists("pending.txt"), false);
    gate.answer(r.command_id, "approve");
    const done = body(await call(loop, "terminal_status", { command_id: r.command_id, wait_seconds: 10 }));
    assert.equal(done.state, "completed");
  });

  test("cancel works on pending commands through the Worker path", async () => {
    const loop = makeLoop({ approver: silentApprover() });
    const r = body(await call(loop, "terminal_execute", { command: "touch never.txt" }));
    const c = body(await call(loop, "terminal_cancel", { command_id: r.command_id }));
    assert.equal(c.state, "cancelled");
    assert.equal(loop.ws.exists("never.txt"), false);
  });

  test("status lists recent commands", async () => {
    const loop = makeLoop();
    await call(loop, "terminal_execute", { command: "echo one" });
    const list = body(await call(loop, "terminal_status", {}));
    assert.equal(list.commands.length, 1);
    assert.equal(list.agent_connected, true);
  });

  test("unknown ids and malformed arguments are errors", async () => {
    const loop = makeLoop();
    assert.equal((await call(loop, "terminal_status", { command_id: "f".repeat(32) })).isError, true);
    assert.equal((await call(loop, "terminal_execute", { command: "" })).isError, true);
    assert.equal((await call(loop, "terminal_cancel", {})).isError, true);
    assert.equal((await call(loop, "terminal_nope", {})).isError, true);
  });
});

describe("TEST 14 duplicate and excessive requests", () => {
  test("every request gets a fresh unpredictable id", async () => {
    const loop = makeLoop();
    const a = body(await call(loop, "terminal_execute", { command: "echo a" })).command_id;
    const b = body(await call(loop, "terminal_execute", { command: "echo a" })).command_id;
    assert.notEqual(a, b);
    assert.match(a, /^[a-f0-9]{32}$/);
  });

  test("too many active commands are refused", async () => {
    const loop = makeLoop({ approver: silentApprover() });
    for (let i = 0; i < EXEC_LIMITS.MAX_ACTIVE_JOBS; i++) await call(loop, "terminal_execute", { command: `echo ${i}` });
    const r = await call(loop, "terminal_execute", { command: "echo overflow" });
    assert.equal(r.isError, true);
    assert.match(r.content[0].text, /too_many_active/);
  });
});

describe("TEST 15 and 16 disconnects, reconnects and restarts", () => {
  test("the WebSocket drops while a command runs; the result still arrives after reconnect", async () => {
    const loop = makeLoop();
    loop.ws.write("slow.js", "setTimeout(()=>require('fs').writeFileSync('done.txt','1'),800)");
    const id = body(await call(loop, "terminal_execute", { command: "node slow.js", timeout_seconds: 20 })).command_id;
    await waitUntil(async () => (await loop.jobs.get(id))?.state === "running", 5000, "running at the Worker");

    loop.link.connected = false;                         // connection lost mid-run
    await new Promise(r => setTimeout(r, 1500));          // the command finishes while offline
    assert.equal(loop.ws.exists("done.txt"), true, "the command itself keeps running");
    assert.equal((await loop.jobs.get(id)).state, "running", "the Worker cannot know yet: it must not claim success");

    await loop.reconnect();                              // agent reconnects and syncs
    await waitUntil(async () => (await loop.jobs.get(id))?.state === "completed", 3000, "completed after sync");
    const done = body(await call(loop, "terminal_status", { command_id: id }));
    assert.equal(done.exit_code, 0);
    assert.equal(done.succeeded, true);
  });

  test("approval requests survive a reconnect and can still be approved once", async () => {
    const gate = gatedApprover();
    const loop = makeLoop({ approver: gate });
    const id = body(await call(loop, "terminal_execute", { command: "touch survive.txt" })).command_id;
    loop.link.connected = false;
    await loop.reconnect();
    assert.equal((await loop.jobs.get(id)).state, "pending_approval");
    gate.answer(id, "approve");
    await waitUntil(async () => (await loop.jobs.get(id))?.state === "completed", 5000, "completion");
    assert.equal(loop.ws.exists("survive.txt"), true);
  });

  test("the agent restarts mid-command: the outcome is 'lost', never success", async () => {
    const loop = makeLoop();
    const id = body(await call(loop, "terminal_execute", { command: "sleep 20", timeout_seconds: 30 })).command_id;
    await waitUntil(async () => (await loop.jobs.get(id))?.state === "running", 5000, "running");
    loop.link.connected = false;
    loop.restartAgent();                                 // process killed, memory gone
    await loop.reconnect();
    const j = body(await call(loop, "terminal_status", { command_id: id }));
    assert.equal(j.state, "lost");
    assert.equal(j.succeeded, false);
    assert.match(j.next_step, /UNKNOWN/);
  });

  test("after a restart the agent accepts new commands normally", async () => {
    const loop = makeLoop();
    loop.restartAgent();
    await loop.reconnect();
    const id = body(await call(loop, "terminal_execute", { command: "echo again" })).command_id;
    const j = body(await call(loop, "terminal_status", { command_id: id, wait_seconds: 10 }));
    assert.equal(j.succeeded, true);
  });

  test("a job whose agent stays silent for a very long time is marked lost", async () => {
    let t = 1_000_000;
    const loop = makeLoop({ approver: silentApprover(), now: () => t });
    loop.link.connected = true;
    const id = body(await call(loop, "terminal_execute", { command: "echo x" })).command_id;
    t += (30 + EXEC_LIMITS.LOST_AFTER_EXTRA_S + 5) * 1000;
    assert.equal((await loop.jobs.get(id)).state, "lost");
  });
});

describe("the agent is not trusted: what it reports is sanitised", () => {
  const base = { command_id: "a".repeat(32), state: "completed", exit_code: 0 };

  test("it cannot claim Worker-only states or send malformed ids", () => {
    assert.equal(sanitizeAgentJob({ ...base, state: "lost" }), null);
    assert.equal(sanitizeAgentJob({ ...base, state: "sent" }), null);
    assert.equal(sanitizeAgentJob({ ...base, state: "bogus" }), null);
    assert.equal(sanitizeAgentJob({ ...base, command_id: "../x" }), null);
    assert.equal(sanitizeAgentJob("string"), null);
  });

  test("it cannot create jobs, resurrect finished ones, or smuggle extra fields", async () => {
    const loop = makeLoop();
    const id = body(await call(loop, "terminal_execute", { command: "echo ok" })).command_id;
    await call(loop, "terminal_status", { command_id: id, wait_seconds: 10 });

    assert.equal(await loop.jobs.onAgentUpdate({ command_id: "b".repeat(32), state: "completed", exit_code: 0 }), false, "unknown job");
    assert.equal(await loop.jobs.onAgentUpdate({ command_id: id, state: "running" }), false, "finished job must not regress");
    assert.equal((await loop.jobs.get(id)).state, "completed");

    const clean = sanitizeAgentJob({ ...base, evil: "x", stdout: "y".repeat(EXEC_LIMITS.MAX_STREAM_CHARS + 500), exit_code: "0" });
    assert.equal(clean.evil, undefined);
    assert.equal(clean.stdout.length, EXEC_LIMITS.MAX_STREAM_CHARS);
    assert.equal(clean.exit_code, undefined, "a non-integer exit code is dropped, so it can never read as success");
  });

  test("success requires state=completed AND exit_code=0", () => {
    const mk = o => presentJob({ command_id: "a".repeat(32), command: "x", created_at: 1, ...o }).succeeded;
    assert.equal(mk({ state: "completed", exit_code: 0 }), true);
    assert.equal(mk({ state: "completed", exit_code: 1 }), false);
    assert.equal(mk({ state: "completed" }), false);
    assert.equal(mk({ state: "completed", exit_code: null }), false);
    for (const s of ["running", "timed_out", "cancelled", "lost", "blocked", "error", "output_limit", "expired", "rejected"]) {
      assert.equal(mk({ state: s, exit_code: 0 }), false, s);
    }
  });
});
