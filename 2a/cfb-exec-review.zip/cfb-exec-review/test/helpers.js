// Shared test helpers. Everything here works inside throw-away temp
// directories and only ever runs harmless commands (echo, touch, sleep, node
// scripts we write ourselves). The "human" is a scripted approver.

import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { TERMINAL } from "../src/exec-protocol.js";

const require = createRequire(import.meta.url);
export const agentExec = require("../termux/agent-exec.js");

export const newId = () => crypto.randomBytes(16).toString("hex");

export function makeWorkspace(overrides = {}) {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), "cfb-test-"));
  const base = path.join(home, "cfb");
  const proj = path.join(base, "proj");
  fs.mkdirSync(proj, { recursive: true });
  fs.mkdirSync(path.join(home, ".cfb"));
  fs.writeFileSync(
    path.join(home, ".cfb", "config.json"),
    JSON.stringify({ exec: { enabled: true, roots: [base], default_cwd: proj } })
  );
  fs.writeFileSync(path.join(home, ".cfb", "bridge.token"), "TOKEN-VALUE-1234567890");

  const config = agentExec.loadConfig({ home });
  assert.equal(config.enabled, true, `config should load: ${config.reason}`);
  Object.assign(config, overrides);

  return {
    home,
    base: config.baseReal,
    proj: config.defaultCwd,
    config,
    write(rel, text) {
      const p = path.join(config.defaultCwd, rel);
      fs.mkdirSync(path.dirname(p), { recursive: true });
      fs.writeFileSync(p, text);
      return p;
    },
    exists: rel => fs.existsSync(path.join(config.defaultCwd, rel)),
    cleanup() { fs.rmSync(home, { recursive: true, force: true }); }
  };
}

export async function waitUntil(fn, ms = 15000, what = "condition") {
  const end = Date.now() + ms;
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() > end) throw new Error(`timed out waiting for ${what}`);
    await new Promise(r => setTimeout(r, 10));
  }
}

// ----- scripted "humans"
export const autoApprover = () => ({ ask: async () => "approve" });
export const rejectApprover = () => ({ ask: async () => "reject" });
// Never answers; resolves "timeout" only when the manager aborts the question.
export const silentApprover = () => ({
  ask: (info, { signal }) => new Promise(resolve => signal.addEventListener("abort", () => resolve("timeout")))
});
// Answers only when the test says so.
export function gatedApprover() {
  const waiting = new Map();
  return {
    asked: [],
    ask(info) {
      this.asked.push(info);
      return new Promise(resolve => waiting.set(info.id, resolve));
    },
    answer(id, decision) { waiting.get(id)?.(decision); }
  };
}

// An agent (manager) with a fake network link to the Worker side.
export function makeAgent(ws, { approver = autoApprover(), secrets = [], link, now } = {}) {
  const sent = [];
  const manager = agentExec.createExecManager({
    config: ws.config,
    approver,
    secrets,
    ...(now ? { now } : {}),
    send: m => {
      if (link && !link.connected) return false;
      sent.push(m);
      link?.deliver?.(m);
      return true;
    }
  });
  const latest = id => {
    for (let i = sent.length - 1; i >= 0; i--) {
      if (sent[i].type === "exec_update" && sent[i].job.command_id === id) return sent[i].job;
    }
    return undefined;
  };
  const states = id => sent.filter(m => m.type === "exec_update" && m.job.command_id === id).map(m => m.job.state);

  async function run(command, { cwd, timeout = 10, id = newId() } = {}) {
    manager.handleRequest({ type: "exec_request", command_id: id, command, working_directory: cwd, timeout_seconds: timeout });
    const job = await waitUntil(() => {
      const j = latest(id);
      return j && TERMINAL.has(j.state) ? j : null;
    }, 20000, `command ${JSON.stringify(command)} to finish`);
    return { id, job };
  }
  function request(command, { cwd, timeout = 10, id = newId() } = {}) {
    manager.handleRequest({ type: "exec_request", command_id: id, command, working_directory: cwd, timeout_seconds: timeout });
    return id;
  }
  return { manager, sent, latest, states, run, request };
}
